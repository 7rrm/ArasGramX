/*
 * This is the source code of Telegram for Android v. 5.x.x.
 * It is licensed under GNU GPL v. 2 or later.
 * You should have received a copy of the license in this archive (see LICENSE).
 *
 * Copyright Nikolai Kudashov, 2013-2018.
 */

package org.telegram.ui.ActionBar;

import static org.telegram.messenger.AndroidUtilities.dp;
import static org.telegram.messenger.AndroidUtilities.dpf2;
import static org.telegram.messenger.AndroidUtilities.find;
import static org.telegram.messenger.AndroidUtilities.lerp;
import static org.telegram.messenger.LocaleController.getString;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.text.Layout;
import android.text.SpannableString;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.transition.ChangeBounds;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.transition.TransitionValues;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.annotation.NonNull;
import androidx.core.graphics.ColorUtils;
import androidx.recyclerview.widget.RecyclerView;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.LocaleController;
import org.telegram.messenger.NotificationCenter;
import org.telegram.messenger.R;
import org.telegram.messenger.SharedConfig;
import org.telegram.messenger.UserConfig;
import org.telegram.ui.Adapters.FiltersView;
import org.telegram.ui.Components.AnimatedEmojiDrawable;
import org.telegram.ui.Components.BackupImageView;
import org.telegram.ui.Components.ChatAvatarContainer;
import org.telegram.ui.Components.CubicBezierInterpolator;
import org.telegram.ui.Components.EllipsizeSpanAnimator;
import org.telegram.ui.Components.FireworksEffect;
import org.telegram.ui.Components.LayoutHelper;
import org.telegram.ui.Components.SectionsScrollView;
import org.telegram.ui.Components.SizeNotifierFrameLayout;
import org.telegram.ui.Components.SnowflakesEffect;
import org.telegram.ui.Components.blur3.BlurredBackgroundDrawableViewFactory;
import org.telegram.ui.Components.blur3.drawable.BlurredBackgroundDrawable;
import org.telegram.ui.Components.blur3.drawable.color.BlurredBackgroundColorProvider;
import org.telegram.ui.MainTabsLayout;

import java.util.ArrayList;

import me.vkryl.android.animator.BoolAnimator;
import me.vkryl.android.animator.FactorAnimator;
import me.vkryl.android.animator.ReplaceAnimator;

import tw.nekomimi.nekogram.NekoConfig;
import xyz.nextalone.nagram.NaConfig;

public class ActionBar extends FrameLayout implements FactorAnimator.Target, Theme.Colorable {

    public static class ActionBarMenuOnItemClick {
        public void onItemClick(int id) {

        }

        public boolean canOpenMenu() {
            return true;
        }
    }

    private BlurredBackgroundDrawable glassDrawable;
    private BlurredBackgroundDrawable glassDrawableBack;
    private BlurredBackgroundDrawable glassDrawableMenu;
    private INavigationLayout.BackButtonState backButtonState = INavigationLayout.BackButtonState.BACK;
    public UnreadImageView backButtonImageView;
    private BackupImageView avatarSearchImageView;
    private Drawable backButtonDrawable;
    private final SimpleTextView[] titleTextView = new SimpleTextView[2];
    private SimpleTextView subtitleTextView;
    private SimpleTextView additionalSubtitleTextView;
    private View actionModeTop;
    private int actionModeColor;
    private int actionBarColor;
    private boolean isMenuOffsetSuppressed;
    public ActionBarMenu menu;
    private ActionBarMenu actionMode;
    private String actionModeTag;
    private boolean ignoreLayoutRequest;
    protected boolean occupyStatusBar = true;
    protected boolean actionModeVisible;
    private boolean addToContainer = true;
    private boolean clipContent;
    private boolean interceptTouches = true;
    private boolean forceSkipTouches;
    private int extraHeight;
    private AnimatorSet actionModeAnimation;
    private View actionModeExtraView;
    private View actionModeTranslationView;
    private View actionModeShowingView;
    private View[] actionModeHidingViews;

    private boolean supportsHolidayImage;
    private SnowflakesEffect snowflakesEffect;
    private FireworksEffect fireworksEffect;
    private Paint.FontMetricsInt fontMetricsInt;
    private boolean manualStart;
    private Rect rect;

    private int titleRightMargin;

    private boolean allowOverlayTitle;
    private CharSequence lastTitle;
    private Drawable lastRightDrawable;
    private OnClickListener rightDrawableOnClickListener;
    private CharSequence lastOverlayTitle;
    private Object[] overlayTitleToSet = new Object[3];
    private Runnable lastRunnable;
    private boolean titleOverlayShown;
    private Runnable titleActionRunnable;
    private boolean castShadows = true;
    private boolean titleScrollNonFitText;
    private int shadowAlpha = 0xFF;

    public boolean menuOccupyBack;
    protected boolean isSearchFieldVisible;
    public float searchFieldVisibleAlpha;
    public int itemsBackgroundColor;
    protected int itemsActionModeBackgroundColor;
    protected int itemsColor;
    protected int itemsActionModeColor;
    private boolean isBackOverlayVisible;
    protected BaseFragment parentFragment;
    public ActionBarMenuOnItemClick actionBarMenuOnItemClick;
    private int titleColorToSet = 0;
    private boolean overlayTitleAnimation;
    private boolean titleAnimationRunning;
    private boolean fromBottom;
    private boolean centerScale;
    private CharSequence subtitle;
    private boolean drawBackButton;
    private boolean attached;
    private boolean resumed;
    private boolean attachState;
    private FrameLayout titlesContainer;
    private boolean useContainerForTitles;

    private View.OnTouchListener interceptTouchEventListener;
    private final Theme.ResourcesProvider resourcesProvider;

    SizeNotifierFrameLayout contentView;
    boolean blurredBackground;
    public Paint blurScrimPaint = new Paint();
    Rect rectTmp = new Rect();

    EllipsizeSpanAnimator ellipsizeSpanAnimator = new EllipsizeSpanAnimator(this);

    public ActionBar(Context context) {
        this(context, null);
    }

    public ActionBar(Context context, Theme.ResourcesProvider resourcesProvider) {
        super(context);
        this.resourcesProvider = resourcesProvider;
        setOnClickListener(v -> {
            if (isSearchFieldVisible()) {
                return;
            }
            if (titleActionRunnable != null) {
                titleActionRunnable.run();
            }
        });
    }

    private boolean glassMode;
    private boolean glassOnlyBack;
    private boolean glassModeIsForum;

    private ChatAvatarContainer chatAvatarContainer;
    // MeeroX v254 (cherry-parity): centered-title owns a dedicated container slot,
    // the glass pill hugs it with an animated adaptive width
    private ChatAvatarContainer chatAvatarContainer2;

    public void setChatAvatarContainer2(ChatAvatarContainer chatAvatarContainer) {
        this.chatAvatarContainer2 = chatAvatarContainer;
    }

    public void setGlassOnlyBack() {
        glassOnlyBack = true;
    }

    public void setChatAvatarContainer(ChatAvatarContainer chatAvatarContainer) {
        this.chatAvatarContainer = chatAvatarContainer;
    }

    // MeeroX v254: Adaptive bubble width (Cherrygram port)
    private boolean meeroForceAdaptiveWidth;
    private final FactorAnimator animatorAdaptiveWidth = new FactorAnimator(0, this, CubicBezierInterpolator.EASE_OUT_QUINT, 380);

    public void setForceAdaptiveWidth(boolean forceAdaptiveWidth) {
        this.meeroForceAdaptiveWidth = forceAdaptiveWidth;
        invalidate();
    }

    private boolean isAdaptiveWidthSupported() {
        if (chatAvatarContainer2 == null || chatAvatarContainer2.getTitleTextView() == null) {
            return false;
        }
        if (meeroForceAdaptiveWidth) {
            return true;
        }
        try {
            return tw.nekomimi.nekogram.NekoConfig.meeroCherryAdaptive.Bool() && chatAvatarContainer2.isCentered();
        } catch (Throwable e) {
            return false;
        }
    }

    private int getBackPillWidth() {
        return dp(46) + dp(6) * 2;
    }

    public int getBackPillGrowth() {
        return 0; // MeeroX v254: normal unread-chip only (iOS counter pill intentionally not ported - his pick)
    }

    public void setupGlass(BlurredBackgroundDrawableViewFactory factory, BlurredBackgroundColorProvider colorProvider) {
        setupGlass(factory, colorProvider, false);
    }

    public void setupGlass(BlurredBackgroundDrawableViewFactory factory,
                           BlurredBackgroundColorProvider colorProvider,
                           boolean isForum) {
        setBackground(null);
        setClipChildren(false);
        glassMode = true;
        glassModeIsForum = isForum;

        glassDrawable = factory.create(this)
            .setColorProvider(colorProvider)
            .setPadding(dp(6));
        if (isForum) {
            glassDrawable.setRadius(dp(18.33f), dp(23), dp(23), dp(18.33f));
        } else {
            glassDrawable.setRadius(dp(23));
        }


        glassDrawableBack = factory.create(this)
            .setColorProvider(colorProvider)
            .setRadius(dp(23))
            .setPadding(dp(6));

        glassDrawableMenu = factory.create(this)
            .setColorProvider(colorProvider)
            .setRadius(dp(23))
            .setPadding(dp(6));

        if (menu != null) {
            menu.setTranslationX(-dp(10));
            menu.setGlassMode(true);
        }
        if (actionMode != null) {
            actionMode.setTranslationX(-dp(10));
            actionMode.setGlassMode(true);
        }
        if (backButtonImageView != null) {
            backButtonImageView.setTranslationX(dp(2));
        }
    }

    public INavigationLayout.BackButtonState getBackButtonState() {
        if (backButtonDrawable instanceof INavigationLayout.IBackButtonDrawable) {
            return ((INavigationLayout.IBackButtonDrawable) backButtonDrawable).getBackButtonState();
        }
        return backButtonState;
    }

    private void createBackButtonImage() {
        if (backButtonImageView != null) {
            return;
        }
        backButtonImageView = new UnreadImageView(getContext());
        backButtonImageView.setScaleType(ImageView.ScaleType.CENTER);
        backButtonImageView.setBackgroundDrawable(Theme.createSelectorDrawable(itemsBackgroundColor));
        backButtonImageView.setPadding(dp(1), 0, 0, 0);
        addView(backButtonImageView, LayoutHelper.createFrame(54, 54, Gravity.LEFT | Gravity.TOP));

        backButtonImageView.setOnClickListener(v -> {
            if (!actionModeVisible && isSearchFieldVisible) {
                closeSearchField();
                return;
            }
            if (actionBarMenuOnItemClick != null) {
                actionBarMenuOnItemClick.onItemClick(-1);
            }
        });
        backButtonImageView.setContentDescription(LocaleController.getString(R.string.AccDescrGoBack));
    }

    public Drawable getBackButtonDrawable() {
        return backButtonDrawable;
    }

    public void setBackButtonDrawable(Drawable drawable) {
        if (backButtonImageView == null) {
            createBackButtonImage();
        }
        backButtonImageView.setVisibility(drawable == null ? GONE : VISIBLE);
        backButtonImageView.setImageDrawable(backButtonDrawable = drawable);
        if (drawable instanceof BackDrawable) {
            BackDrawable backDrawable = (BackDrawable) drawable;
            backDrawable.setRotation(isActionModeShowed() ? 1 : 0, false);
            backDrawable.setRotatedColor(itemsActionModeColor);
            backDrawable.setColor(itemsColor);
        } else if (drawable instanceof MenuDrawable) {
            MenuDrawable menuDrawable = (MenuDrawable) drawable;
            menuDrawable.setBackColor(actionBarColor);
            menuDrawable.setIconColor(itemsColor);
        } else if (drawable instanceof BitmapDrawable || drawable instanceof VectorDrawable) {
            backButtonImageView.setColorFilter(new PorterDuffColorFilter(itemsColor, PorterDuff.Mode.SRC_IN));
        }
        if (mAlwaysApplyColorFilterToBackButton) {
            backButtonImageView.setColorFilter(new PorterDuffColorFilter(itemsColor, PorterDuff.Mode.SRC_IN));
        }

        checkBackButtonLayerType();
    }

    private void checkBackButtonLayerType() {
        if (backButtonImageView == null) {
            return;
        }

        // BackDrawable is expensive for render thread because it uses PathStencilCoverOp

        final Drawable drawable = backButtonImageView.getDrawable();
        final int layerToSet = (drawable instanceof BackDrawable || drawable instanceof MenuDrawable) ?
            View.LAYER_TYPE_HARDWARE :
            View.LAYER_TYPE_NONE;

        if (backButtonImageView.getLayerType() != layerToSet) {
            backButtonImageView.setLayerType(layerToSet, null);
            backButtonImageView.invalidate();
        }
    }

    public void setBackButtonContentDescription(CharSequence description) {
        if (backButtonImageView != null) {
            backButtonImageView.setContentDescription(description);
        }
    }

    public void setSupportsHolidayImage(boolean value) {
        supportsHolidayImage = value;
        if (supportsHolidayImage) {
            fontMetricsInt = new Paint.FontMetricsInt();
            rect = new Rect();
        }
        invalidate();
    }

    public BackupImageView getSearchAvatarImageView() {
        return avatarSearchImageView;
    }

    public void setSearchAvatarImageView(BackupImageView backupImageView) {
        if (avatarSearchImageView == backupImageView) {
            return;
        }
        if (avatarSearchImageView != null) {
            removeView(avatarSearchImageView);
        }
        avatarSearchImageView = backupImageView;
        if (avatarSearchImageView != null) {
            addView(avatarSearchImageView);
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (supportsHolidayImage && !titleOverlayShown && !LocaleController.isRTL && ev.getAction() == MotionEvent.ACTION_DOWN) {
            Drawable drawable = Theme.getCurrentHolidayDrawable();
            if (drawable != null && drawable.getBounds().contains((int) ev.getX(), (int) ev.getY())) {
                manualStart = true;
                if (snowflakesEffect == null) {
                    fireworksEffect = null;
                    snowflakesEffect = new SnowflakesEffect(0);
                    titleTextView[0].invalidate();
                    invalidate();
                } else {
                    snowflakesEffect = null;
                    fireworksEffect = new FireworksEffect();
                    titleTextView[0].invalidate();
                    invalidate();
                }
            }
        }
        return interceptTouchEventListener != null && interceptTouchEventListener.onTouch(this, ev) || super.onInterceptTouchEvent(ev);
    }

    protected boolean shouldClipChild(View child) {
        return clipContent && (child == titleTextView[0] || child == titleTextView[1] || child == subtitleTextView || child == menu || child == backButtonImageView || child == additionalSubtitleTextView || child == titlesContainer);
    }

    @Override
    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
        if (parentFragment != null && parentFragment.getParentLayout() != null && parentFragment.getParentLayout().isActionBarInCrossfade()) {
            return false;
        }
        if (drawBackButton && child == backButtonImageView) {
            return true;
        }

        boolean clip = shouldClipChild(child);
        if (clip) {
            canvas.save();
            canvas.clipRect(0, -getTranslationY() + (occupyStatusBar ? AndroidUtilities.statusBarHeight : 0), getMeasuredWidth(), getMeasuredHeight());
        }
        boolean result = super.drawChild(canvas, child, drawingTime);
        if (supportsHolidayImage && !titleOverlayShown && !LocaleController.isRTL && (child == titleTextView[0] || child == titleTextView[1] || child == titlesContainer && useContainerForTitles)) {
            Drawable drawable = Theme.getCurrentHolidayDrawable();
            if (drawable != null) {
                SimpleTextView titleView = child == titlesContainer ? titleTextView[0] : (SimpleTextView) child;
                if (titleView != null && titleView.getVisibility() == View.VISIBLE && titleView.getText() instanceof String) {
                    TextPaint textPaint = titleView.getTextPaint();
                    textPaint.getFontMetricsInt(fontMetricsInt);
                    textPaint.getTextBounds((String) titleView.getText(), 0, 1, rect);
                    int x = titleView.getTextStartX() + Theme.getCurrentHolidayDrawableXOffset() + (rect.width() - (drawable.getIntrinsicWidth() + Theme.getCurrentHolidayDrawableXOffset())) / 2;
                    int y = titleView.getTextStartY() + Theme.getCurrentHolidayDrawableYOffset() + (int) Math.ceil((titleView.getTextHeight() - rect.height()) / 2.0f) + (int) (dp(8) * (1f - titlesContainer.getScaleY()));
                    drawable.setBounds(x, y - drawable.getIntrinsicHeight(), x + drawable.getIntrinsicWidth(), y);
                    drawable.setAlpha((int) (255 * titlesContainer.getAlpha() * titleView.getAlpha()));
                    drawable.draw(canvas);
                    if (overlayTitleAnimationInProgress) {
                        child.invalidate();
                        invalidate();
                    }
                }
            }
            if (NekoConfig.actionBarDecoration.Int() == 3) {
                if (snowflakesEffect != null) {
                    snowflakesEffect = null;
                }
                if (fireworksEffect != null) {
                    fireworksEffect = null;
                }
            } else if (NekoConfig.actionBarDecoration.Int() == 2) {
                if (fireworksEffect == null) {
                    fireworksEffect = new FireworksEffect();
                }
            } else if (NekoConfig.actionBarDecoration.Int() == 1 || Theme.canStartHolidayAnimation()) {
                if (snowflakesEffect == null) {
                    snowflakesEffect = new SnowflakesEffect(0);
                }
            } else if (!manualStart) {
                if (snowflakesEffect != null) {
                    snowflakesEffect = null;
                }
                if (fireworksEffect != null) {
                    fireworksEffect = null;
                }
            }
            if (snowflakesEffect != null) {
                snowflakesEffect.onDraw(this, canvas);
            } else if (fireworksEffect != null) {
                fireworksEffect.onDraw(this, canvas);
            }
        }
        if (clip) {
            canvas.restore();
        }
        return result;
    }

    @Override
    public void setTranslationY(float translationY) {
        super.setTranslationY(translationY);
        if (clipContent) {
            invalidate();
        }
    }

    public void setBackButtonImage(int resource) {
        if (backButtonImageView == null) {
            createBackButtonImage();
        }
        backButtonImageView.setVisibility(resource == 0 ? GONE : VISIBLE);
        backButtonImageView.setImageResource(resource);
        backButtonImageView.setColorFilter(new PorterDuffColorFilter(itemsColor, PorterDuff.Mode.SRC_IN));
        checkBackButtonLayerType();
    }

    private boolean mAlwaysApplyColorFilterToBackButton;

    public void alwaysApplyColorFilterToBackButton() {
        mAlwaysApplyColorFilterToBackButton = true;
    }

    private void createSubtitleTextView() {
        if (subtitleTextView != null) {
            return;
        }
        subtitleTextView = new SimpleTextView(getContext());
        subtitleTextView.setGravity(isCentered() ? Gravity.CENTER : Gravity.LEFT);
        subtitleTextView.setVisibility(GONE);
        subtitleTextView.setTextColor(getThemedColor(Theme.key_actionBarDefaultSubtitle));
        addView(subtitleTextView, 0, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT, Gravity.LEFT | Gravity.TOP));
    }

    public void createAdditionalSubtitleTextView() {
        if (additionalSubtitleTextView != null) {
            return;
        }
        additionalSubtitleTextView = new SimpleTextView(getContext());
        additionalSubtitleTextView.setGravity(isCentered() ? Gravity.CENTER : Gravity.LEFT);
        additionalSubtitleTextView.setVisibility(GONE);
        additionalSubtitleTextView.setTextColor(getThemedColor(Theme.key_actionBarDefaultSubtitle));
        addView(additionalSubtitleTextView, 0, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT, Gravity.LEFT | Gravity.TOP));
    }

    public SimpleTextView getAdditionalSubtitleTextView() {
        return additionalSubtitleTextView;
    }

    public void setAddToContainer(boolean value) {
        addToContainer = value;
    }

    public boolean shouldAddToContainer() {
        return addToContainer;
    }

    public void setClipContent(boolean value) {
        clipContent = value;
    }

    public void setSubtitle(CharSequence value) {
        if (value != null && subtitleTextView == null) {
            createSubtitleTextView();
        }
        if (subtitleTextView != null) {
            boolean isEmpty = TextUtils.isEmpty(value);
            subtitleTextView.setVisibility(!isEmpty && !isSearchFieldVisible ? VISIBLE : GONE);
            subtitleTextView.setAlpha(1f);
            if (!isEmpty) {
                subtitleTextView.setText(value);
            }
            subtitle = value;
        }
    }

    private void createTitleTextView(int i) {
        if (titleTextView[i] != null) {
            return;
        }
        titleTextView[i] = new SimpleTextView(getContext());
        titleTextView[i].setGravity(/*isCenterTitle*/isCentered() ? Gravity.CENTER : Gravity.LEFT | Gravity.CENTER_VERTICAL);
        if (titleColorToSet != 0) {
            titleTextView[i].setTextColor(titleColorToSet);
        } else {
            titleTextView[i].setTextColor(getThemedColor(Theme.key_actionBarDefaultTitle));
        }
        titleTextView[i].setEmojiColor(titleTextView[i].getTextColor());
        titleTextView[i].setTypeface(AndroidUtilities.bold());
        titleTextView[i].setDrawablePadding(dp(4));
        titleTextView[i].setPadding(0, dp(8), 0, dp(8));
        titleTextView[i].setRightDrawableTopPadding(-dp(1));
        if (useContainerForTitles) {
            titlesContainer.addView(titleTextView[i], 0, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT, Gravity.LEFT | Gravity.TOP));
        } else {
            addView(titleTextView[i], 0, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT, Gravity.LEFT | Gravity.TOP));
        }
        if (NaConfig.INSTANCE.getCustomTitleUserName().Bool() && titleScrollNonFitText) {
            titleTextView[i].setScrollNonFitText(true);
        }
    }

    private boolean isCenterTitle;

    public void centerTitle() {
        isCenterTitle = true;
        if (titleTextView != null) {
            for (int a = 0; a < titleTextView.length; a++) {
                if (titleTextView[a] != null) {
                    titleTextView[a].setGravity(Gravity.CENTER);
                }
            }
        }
    }

    public void setTitleRightMargin(int value) {
        titleRightMargin = value;
    }

    public void setTitle(CharSequence value) {
        setTitle(value, null);
    }

    public void setTitle(CharSequence value, Drawable rightDrawable) {
        if (value != null && titleTextView[0] == null) {
            createTitleTextView(0);
        }
        if (titleTextView[0] != null) {
            titleTextView[0].setVisibility(value != null && !isSearchFieldVisible ? VISIBLE : INVISIBLE);
            titleTextView[0].setText(lastTitle = value);
            if (UserConfig.getInstance(UserConfig.selectedAccount).isPremiumOrLocal() || (NekoConfig.isGhostModeActive() && NekoConfig.showGhostModeStatus.Bool())) {
                if (attached && lastRightDrawable instanceof AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) {
                    ((AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) lastRightDrawable).setParentView(null);
                }
                titleTextView[0].setRightDrawable(lastRightDrawable = rightDrawable);
                if (attached && lastRightDrawable instanceof AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) {
                    ((AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) lastRightDrawable).setParentView(titleTextView[0]);
                }
                titleTextView[0].setRightDrawableOnClick(rightDrawableOnClickListener);
            }
        }
        fromBottom = false;
    }

    public void setRightDrawableOnClick(OnClickListener onClickListener) {
        rightDrawableOnClickListener = onClickListener;
        if (titleTextView[0] != null) {
            titleTextView[0].setRightDrawableOnClick(rightDrawableOnClickListener);
        }
        if (titleTextView[1] != null) {
            titleTextView[1].setRightDrawableOnClick(rightDrawableOnClickListener);
        }
    }

    public void setTitleColor(int color) {
        if (titleTextView[0] == null) {
            createTitleTextView(0);
        }
        titleColorToSet = color;
        titleTextView[0].setTextColor(color);
        titleTextView[0].setEmojiColor(color);
        if (titleTextView[1] != null) {
            titleTextView[1].setTextColor(color);
            titleTextView[1].setEmojiColor(color);
        }
        // MeeroX: the connecting ring takes its colour from the title's paint
        // at the moment it is attached, so a later recolour would leave it on
        // the old one. That is not hypothetical: DialogsActivity recolours the
        // title to the logo colour after the bar is built, and switching
        // between a light and dark theme recolours every title on screen.
        if (meeroConnectingDrawable != null) {
            meeroConnectingDrawable.setColor(color);
        }
    }

    public void setSubtitleColor(int color) {
        if (subtitleTextView == null) {
            createSubtitleTextView();
        }
        subtitleTextView.setTextColor(color);
    }

    public void setTitleScrollNonFitText(boolean b) {
        if (titleTextView[0] != null) {
            titleTextView[0].setScrollNonFitText(b);
        }
        if (NaConfig.INSTANCE.getCustomTitleUserName().Bool()) {
            titleScrollNonFitText = b;
        }
    }

    public void setPopupItemsColor(int color, boolean icon, boolean forActionMode) {
        if (forActionMode && actionMode != null) {
            actionMode.setPopupItemsColor(color, icon);
        } else if (!forActionMode && menu != null) {
            menu.setPopupItemsColor(color, icon);
        }
    }

    public void setPopupItemsSelectorColor(int color, boolean forActionMode) {
        if (forActionMode && actionMode != null) {
            actionMode.setPopupItemsSelectorColor(color);
        } else if (!forActionMode && menu != null) {
            menu.setPopupItemsSelectorColor(color);
        }
    }

    public void setPopupBackgroundColor(int color, boolean forActionMode) {
        if (forActionMode && actionMode != null) {
            actionMode.redrawPopup(color);
        } else if (!forActionMode && menu != null) {
            menu.redrawPopup(color);
        }
    }

    public SimpleTextView getSubtitleTextView() {
        return subtitleTextView;
    }

    public SimpleTextView getTitleTextView() {
        return titleTextView[0];
    }

    public Paint.FontMetricsInt getTitleFontMetricsInt() {
        if (titleTextView[0] == null) {
            TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            paint.setTextSize(dp(!AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 18 : 20));
            return paint.getFontMetricsInt();
        }
        return titleTextView[0].getPaint().getFontMetricsInt();
    }

    public SimpleTextView getTitleTextView2() {
        return titleTextView[1];
    }

    public String getTitle() {
        if (titleTextView[0] == null) {
            return null;
        }
        return titleTextView[0].getText().toString();
    }

    public String getSubtitle() {
        if (subtitleTextView == null || subtitle == null) {
            return null;
        }
        return subtitle.toString();
    }

    public ActionBarMenu createMenu() {
        if (menu != null) {
            return menu;
        }
        menu = new ActionBarMenu(getContext(), this);
        addView(menu, 0, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.MATCH_PARENT, Gravity.RIGHT));
        return menu;
    }

    public void setActionBarMenuOnItemClick(ActionBarMenuOnItemClick listener) {
        actionBarMenuOnItemClick = listener;
    }

    public ActionBarMenuOnItemClick getActionBarMenuOnItemClick() {
        return actionBarMenuOnItemClick;
    }

    public ImageView getBackButton() {
        return backButtonImageView;
    }

    public ActionBarMenu createActionMode() {
        return createActionMode(true, null);
    }

    public boolean actionModeIsExist(String tag) {
        if (actionMode != null && ((actionModeTag == null && tag == null) || (actionModeTag != null && actionModeTag.equals(tag)))) {
            return true;
        }
        return false;
    }

    private Runnable doOnActionModeFactorChanged;

    public void setOnActionModeFactorChangeListener(Runnable listener) {
        doOnActionModeFactorChanged = listener;
    }

    public float getActionModeFactor() {
        return actionMode != null ? actionMode.getAlpha() : 0;
    }

    public ActionBarMenu createActionMode(boolean needTop, String tag) {
        if (actionModeIsExist(tag)) {
            return actionMode;
        }
        if (actionMode != null) {
            removeView(actionMode);
            actionMode = null;
        }
        actionModeTag = tag;
        actionMode = new ActionBarMenu(getContext(), this) {
            @Override
            public void setBackgroundColor(int color) {
                actionModeColor = color;
                if (!blurredBackground) {
                    super.setBackgroundColor(actionModeColor);
                }
            }

            @Override
            protected void dispatchDraw(Canvas canvas) {
                if (blurredBackground && drawBlur && actionModeColor != 0) {
                    rectTmp.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
                    blurScrimPaint.setColor(actionModeColor);
                    contentView.drawBlurRect(canvas, 0, rectTmp, blurScrimPaint, true);
                }
                super.dispatchDraw(canvas);
            }

            @Override
            public void setAlpha(float alpha) {
                super.setAlpha(alpha);
                ActionBar.this.invalidate();
                if (doOnActionModeFactorChanged != null) {
                    doOnActionModeFactorChanged.run();
                }
            }

            @Override
            protected void onAttachedToWindow() {
                super.onAttachedToWindow();
                if (contentView != null) {
                    contentView.blurBehindViews.add(this);
                }
            }

            @Override
            protected void onDetachedFromWindow() {
                super.onDetachedFromWindow();
                if (contentView != null) {
                    contentView.blurBehindViews.remove(this);
                }
            }
        };
        actionMode.setTranslationX(glassMode ? -dp(10) : 0);
        actionMode.setGlassMode(glassMode);
        actionMode.isActionMode = true;
        actionMode.setClickable(true);
        if (!glassMode) {
            actionMode.setBackgroundColor(getThemedColor(Theme.key_actionBarActionModeDefault));
        }
        addView(actionMode, indexOfChild(backButtonImageView));
        actionMode.setPadding(0, occupyStatusBar ? AndroidUtilities.statusBarHeight : 0, 0, 0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) actionMode.getLayoutParams();
        layoutParams.height = LayoutHelper.MATCH_PARENT;
        layoutParams.width = LayoutHelper.MATCH_PARENT;
        layoutParams.bottomMargin = extraHeight;
        layoutParams.gravity = Gravity.RIGHT;
        actionMode.setLayoutParams(layoutParams);
        actionMode.setVisibility(INVISIBLE);

//        if (occupyStatusBar && needTop && actionModeTop == null && !blurredBackground) {
//            actionModeTop = new View(getContext());
//            actionModeTop.setBackgroundColor(getThemedColor(Theme.key_actionBarActionModeDefaultTop));
//            addView(actionModeTop);
//            layoutParams = (FrameLayout.LayoutParams) actionModeTop.getLayoutParams();
//            layoutParams.height = AndroidUtilities.statusBarHeight;
//            layoutParams.width = LayoutHelper.MATCH_PARENT;
//            layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
//            actionModeTop.setLayoutParams(layoutParams);
//            actionModeTop.setVisibility(INVISIBLE);
//        }

        return actionMode;
    }

    public void onDrawCrossfadeContent(Canvas canvas, boolean front, boolean hideBackDrawable, float progress) {
        for (int i = 0; i < getChildCount(); i++) {
            View ch = getChildAt(i);
            if ((!hideBackDrawable || ch != backButtonImageView) && ch.getVisibility() == View.VISIBLE && ch instanceof ActionBarMenu) {
                canvas.save();
                canvas.translate(ch.getX(), ch.getY());
                ch.draw(canvas);
                canvas.restore();
            }
        }

        canvas.save();
        canvas.translate(front ? getWidth() * progress * 0.5f : -getWidth() * 0.4f * (1f - progress), 0);
        for (int i = 0; i < getChildCount(); i++) {
            View ch = getChildAt(i);
            if ((!hideBackDrawable || ch != backButtonImageView) && ch.getVisibility() == View.VISIBLE && ch.getAlpha() != 0 && !(ch instanceof ActionBarMenu)) {
                canvas.save();
                canvas.translate(ch.getX(), ch.getY());
                ch.draw(canvas);
                canvas.restore();
            }
        }
        canvas.restore();
    }

    public void showActionMode() {
        showActionMode(true, null, null, null, null, null, 0);
    }

    public void showActionMode(boolean animated) {
        showActionMode(animated, null, null, null, null, null, 0);
    }

    public void showActionMode(boolean animated, View extraView, View showingView, View[] hidingViews, boolean[] hideView, View translationView, int translation) {
        if (actionMode == null || actionModeVisible) {
            return;
        }
        actionModeVisible = true;
        checkMenuItemsWidth();
        if (animated) {
            ArrayList<Animator> animators = new ArrayList<>();
            animators.add(ObjectAnimator.ofFloat(actionMode, View.ALPHA, 0.0f, 1.0f));
            if (hidingViews != null) {
                for (int a = 0; a < hidingViews.length; a++) {
                    if (hidingViews[a] != null) {
                        animators.add(ObjectAnimator.ofFloat(hidingViews[a], View.ALPHA, 1.0f, 0.0f));
                    }
                }
            }
            if (showingView != null) {
                animators.add(ObjectAnimator.ofFloat(showingView, View.ALPHA, 0.0f, 1.0f));
            }
            if (translationView != null) {
                animators.add(ObjectAnimator.ofFloat(translationView, View.TRANSLATION_Y, translation));
                actionModeTranslationView = translationView;
            }
            actionModeExtraView = extraView;
            actionModeShowingView = showingView;
            actionModeHidingViews = hidingViews;
            if (actionModeExtraView != null) {
                animators.add(ObjectAnimator.ofFloat(actionModeExtraView, View.TRANSLATION_Y, 0));
            }
            if (actionModeColor == 0) {
                if (!isSearchFieldVisible) {
                    if (titleTextView[0] != null) {
                        animators.add(ObjectAnimator.ofFloat(titleTextView[0], View.ALPHA, 0));
                    }
                    if (subtitleTextView != null && !TextUtils.isEmpty(subtitle)) {
                        animators.add(ObjectAnimator.ofFloat(subtitleTextView, View.ALPHA, 0));
                    }
                }
                if (menu != null) {
                    animators.add(ObjectAnimator.ofFloat(menu, View.ALPHA, 0));
                }
            }
            final int color = actionModeColor == 0 ? actionBarColor : actionModeColor;
            if (color == 0 || glassMode) {
                NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.needCheckSystemBarColors);
            } else if (ColorUtils.calculateLuminance(color) < 0.7f) {
                AndroidUtilities.setLightStatusBar((Activity) getContext(), false);
            } else {
                AndroidUtilities.setLightStatusBar((Activity) getContext(), true);
            }
            if (actionModeAnimation != null) {
                actionModeAnimation.cancel();
            }
            actionModeAnimation = new AnimatorSet();
            actionModeAnimation.playTogether(animators);
            if (backgroundUpdateListener != null) {
                ValueAnimator alphaUpdate = ValueAnimator.ofFloat(0, 1);
                alphaUpdate.addUpdateListener(anm -> {
                    if (backgroundUpdateListener != null) {
                        backgroundUpdateListener.run();
                    }
                });
                actionModeAnimation.playTogether(alphaUpdate);
            }
            actionModeAnimation.setDuration(200);
            actionModeAnimation.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationStart(Animator animation) {
                    actionMode.setVisibility(VISIBLE);
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    if (actionModeAnimation != null && actionModeAnimation.equals(animation)) {
                        actionModeAnimation = null;
                        if (titleTextView[0] != null) {
                            titleTextView[0].setVisibility(INVISIBLE);
                        }
                        if (subtitleTextView != null && !TextUtils.isEmpty(subtitle)) {
                            subtitleTextView.setVisibility(INVISIBLE);
                        }
                        if (menu != null) {
                            menu.setVisibility(INVISIBLE);
                        }
                        if (actionModeHidingViews != null) {
                            for (int a = 0; a < actionModeHidingViews.length; a++) {
                                if (actionModeHidingViews[a] != null) {
                                    if (hideView == null || a >= hideView.length || hideView[a]) {
                                        actionModeHidingViews[a].setVisibility(INVISIBLE);
                                    }
                                }
                            }
                        }
                    }
                }

                @Override
                public void onAnimationCancel(Animator animation) {
                    if (actionModeAnimation != null && actionModeAnimation.equals(animation)) {
                        actionModeAnimation = null;
                    }
                }
            });
            actionModeAnimation.start();
            if (backButtonImageView != null) {
                Drawable drawable = backButtonImageView.getDrawable();
                if (drawable instanceof BackDrawable) {
                    ((BackDrawable) drawable).setRotation(1, true);
                }
                backButtonImageView.setBackgroundDrawable(Theme.createSelectorDrawable(itemsActionModeBackgroundColor));
            }
        } else {
            actionMode.setAlpha(1.0f);
            if (hidingViews != null) {
                for (int a = 0; a < hidingViews.length; a++) {
                    if (hidingViews[a] != null) {
                        hidingViews[a].setAlpha(0.0f);
                    }
                }
            }
            if (showingView != null) {
                showingView.setAlpha(1.0f);
            }
            if (translationView != null) {
                translationView.setTranslationY(translation);
                actionModeTranslationView = translationView;
            }
            actionModeExtraView = extraView;
            if (actionModeExtraView != null) {
                actionModeExtraView.setTranslationY(0);
            }
            actionModeShowingView = showingView;
            actionModeHidingViews = hidingViews;
            final int color = actionModeColor == 0 ? actionBarColor : actionModeColor;
            if (color == 0 || glassMode) {
                NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.needCheckSystemBarColors);
            } else if (ColorUtils.calculateLuminance(color) < 0.7f) {
                AndroidUtilities.setLightStatusBar((Activity) getContext(), false);
            } else {
                AndroidUtilities.setLightStatusBar((Activity) getContext(), true);
            }
            actionMode.setVisibility(VISIBLE);
            if (titleTextView[0] != null) {
                titleTextView[0].setVisibility(INVISIBLE);
            }
            if (subtitleTextView != null && !TextUtils.isEmpty(subtitle)) {
                subtitleTextView.setVisibility(INVISIBLE);
            }
            if (menu != null) {
                menu.setVisibility(INVISIBLE);
            }
            if (actionModeHidingViews != null) {
                for (int a = 0; a < actionModeHidingViews.length; a++) {
                    if (actionModeHidingViews[a] != null) {
                        if (hideView == null || a >= hideView.length || hideView[a]) {
                            actionModeHidingViews[a].setVisibility(INVISIBLE);
                        }
                    }
                }
            }
            if (backButtonImageView != null) {
                Drawable drawable = backButtonImageView.getDrawable();
                if (drawable instanceof BackDrawable) {
                    ((BackDrawable) drawable).setRotation(1, false);
                }
                backButtonImageView.setBackgroundDrawable(Theme.createSelectorDrawable(itemsActionModeBackgroundColor));
            }
        }
    }

    public void hideActionMode() {
        if (actionMode == null || !actionModeVisible) {
            return;
        }
        actionMode.hideAllPopupMenus();
        actionModeVisible = false;
        checkMenuItemsWidth();
        ArrayList<Animator> animators = new ArrayList<>();
        animators.add(ObjectAnimator.ofFloat(actionMode, View.ALPHA, 0.0f));
        if (actionModeHidingViews != null) {
            for (int a = 0; a < actionModeHidingViews.length; a++) {
                if (actionModeHidingViews[a] != null) {
                    actionModeHidingViews[a].setVisibility(VISIBLE);
                    animators.add(ObjectAnimator.ofFloat(actionModeHidingViews[a], View.ALPHA, 1.0f));
                }
            }
        }
        if (actionModeTranslationView != null) {
            animators.add(ObjectAnimator.ofFloat(actionModeTranslationView, View.TRANSLATION_Y, 0.0f));
            actionModeTranslationView = null;
        }
        if (actionModeShowingView != null) {
            animators.add(ObjectAnimator.ofFloat(actionModeShowingView, View.ALPHA, 0.0f));
        }
        if (actionModeExtraView != null) {
            animators.add(ObjectAnimator.ofFloat(actionModeExtraView, View.TRANSLATION_Y, actionModeExtraView.getMeasuredHeight()));
        }
        if (!isSearchFieldVisible) {
            if (titleTextView[0] != null) {
                animators.add(ObjectAnimator.ofFloat(titleTextView[0], View.ALPHA, 1));
            }
            if (subtitleTextView != null && !TextUtils.isEmpty(subtitle)) {
                animators.add(ObjectAnimator.ofFloat(subtitleTextView, View.ALPHA, 1));
            }
        }
        if (menu != null) {
            animators.add(ObjectAnimator.ofFloat(menu, View.ALPHA, 1));
        }
        if (actionBarColor == 0 || glassMode) {
            NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.needCheckSystemBarColors);
        } else if (ColorUtils.calculateLuminance(actionBarColor) < 0.7f) {
            AndroidUtilities.setLightStatusBar((Activity) getContext(), false);
        } else {
            AndroidUtilities.setLightStatusBar((Activity) getContext(), true);
        }
        if (actionModeAnimation != null) {
            actionModeAnimation.cancel();
        }
        actionModeAnimation = new AnimatorSet();
        actionModeAnimation.playTogether(animators);
        if (backgroundUpdateListener != null) {
            ValueAnimator alphaUpdate = ValueAnimator.ofFloat(0, 1);
            alphaUpdate.addUpdateListener(anm -> {
                if (backgroundUpdateListener != null) {
                    backgroundUpdateListener.run();
                }
            });
            actionModeAnimation.playTogether(alphaUpdate);
        }
        actionModeAnimation.setDuration(200);
        actionModeAnimation.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (actionModeAnimation != null && actionModeAnimation.equals(animation)) {
                    actionModeAnimation = null;
                    actionMode.setVisibility(INVISIBLE);
                    if (actionModeExtraView != null) {
                        actionModeExtraView.setVisibility(INVISIBLE);
                    }
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                if (actionModeAnimation != null && actionModeAnimation.equals(animation)) {
                    actionModeAnimation = null;
                }
            }
        });
        actionModeAnimation.start();
        if (!isSearchFieldVisible) {
            if (titleTextView[0] != null) {
                titleTextView[0].setVisibility(VISIBLE);
            }
            if (subtitleTextView != null && !TextUtils.isEmpty(subtitle)) {
                subtitleTextView.setVisibility(VISIBLE);
            }
        }
        if (menu != null) {
            menu.setVisibility(VISIBLE);
        }
        if (backButtonImageView != null) {
            Drawable drawable = backButtonImageView.getDrawable();
            if (drawable instanceof BackDrawable) {
                ((BackDrawable) drawable).setRotation(0, true);
            }
            backButtonImageView.setBackgroundDrawable(Theme.createSelectorDrawable(itemsBackgroundColor));
        }
    }

    public void showActionModeTop() {
        if (occupyStatusBar && actionModeTop == null) {
            actionModeTop = new View(getContext());
            actionModeTop.setBackgroundColor(getThemedColor(Theme.key_actionBarActionModeDefaultTop));
            addView(actionModeTop);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) actionModeTop.getLayoutParams();
            layoutParams.height = AndroidUtilities.statusBarHeight;
            layoutParams.width = LayoutHelper.MATCH_PARENT;
            layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
            actionModeTop.setLayoutParams(layoutParams);
        }
    }

    public void setActionModeTopColor(int color) {
        if (actionModeTop != null) {
            actionModeTop.setBackgroundColor(color);
        }
    }

    public void setSearchTextColor(int color, boolean placeholder) {
        if (menu != null) {
            menu.setSearchTextColor(color, placeholder);
        }
    }

    public void setSearchCursorColor(int color) {
        if (menu != null) {
            menu.setSearchCursorColor(color);
        }
    }

    public void setActionModeColor(int color) {
        if (actionMode != null) {
            actionMode.setBackgroundColor(color);
        }
    }

    public void setActionModeOverrideColor(int color) {
        actionModeColor = color;
    }

    @Override
    public void setBackgroundColor(int color) {
        actionBarColor = color;
        if (!blurredBackground) {
            super.setBackgroundColor(actionBarColor);
        }
        if (backButtonImageView != null) {
            Drawable drawable = backButtonImageView.getDrawable();
            if (drawable instanceof MenuDrawable) {
                ((MenuDrawable) drawable).setBackColor(color);
            }
        }
    }

    public int getBackgroundColor() {
        return actionBarColor;
    }

    public boolean isActionModeShowed() {
        return actionMode != null && actionModeVisible;
    }

    public boolean isActionModeShowed(String tag) {
        return actionMode != null && actionModeVisible && ((actionModeTag == null && tag == null) || (actionModeTag != null && actionModeTag.equals(tag)));
    }

    Runnable backgroundUpdateListener;
    AnimatorSet searchVisibleAnimator;

    public void listenToBackgroundUpdate(Runnable invalidate) {
        backgroundUpdateListener = invalidate;
    }

    protected boolean onSearchChangedIgnoreTitles() {
        return false;
    }

    public void onSearchFieldVisibilityChanged(boolean visible) {
        isSearchFieldVisible = visible;
        checkMenuItemsWidth();
        if (searchVisibleAnimator != null) {
            searchVisibleAnimator.cancel();
        }
        searchVisibleAnimator = new AnimatorSet();
        final ArrayList<View> viewsToHide = new ArrayList<>();

        final boolean ignoreTitles = onSearchChangedIgnoreTitles();
        if (!ignoreTitles) {
            if (titleTextView[0] != null) {
                viewsToHide.add(titleTextView[0]);
            }

            if (subtitleTextView != null && !TextUtils.isEmpty(subtitle)) {
                viewsToHide.add(subtitleTextView);
                subtitleTextView.setVisibility(visible ? INVISIBLE : VISIBLE);
            }
        }

        ValueAnimator alphaUpdate = ValueAnimator.ofFloat(searchFieldVisibleAlpha, visible ? 1f : 0f);
        alphaUpdate.addUpdateListener(anm -> {
            searchFieldVisibleAlpha = (float) anm.getAnimatedValue();

            if (glassDrawable != null && glassModeIsForum) {
                final float r1 = dp(23);
                final float r2 = lerp(dp(18.33f), dp(23), searchFieldVisibleAlpha);
                glassDrawable.setRadius(r2, r1, r1, r2);
                invalidate();
            }

            if (glassMode && menu != null) {
                menu.setTranslationX(-lerp((float) dp(10), dp(5), searchFieldVisibleAlpha));
            }
            if (backgroundUpdateListener != null) {
                backgroundUpdateListener.run();
            }
        });
        searchVisibleAnimator.playTogether(alphaUpdate);

        for (int i = 0; i < viewsToHide.size(); i++) {
            View view = viewsToHide.get(i);
            if (!visible) {
                view.setVisibility(View.VISIBLE);
                view.setAlpha(0);
                view.setScaleX(0.95f);
                view.setScaleY(0.95f);
            }
            searchVisibleAnimator.playTogether(ObjectAnimator.ofFloat(view, View.ALPHA, visible ? 0f : 1f));
            searchVisibleAnimator.playTogether(ObjectAnimator.ofFloat(view, View.SCALE_Y, visible ? 0.95f : 1f));
            searchVisibleAnimator.playTogether(ObjectAnimator.ofFloat(view, View.SCALE_X, visible ? 0.95f : 1f));
        }
        if (avatarSearchImageView != null) {
            avatarSearchImageView.setVisibility(View.VISIBLE);
            searchVisibleAnimator.playTogether(ObjectAnimator.ofFloat(avatarSearchImageView, View.ALPHA, visible ? 1f : 0f));
        }
        centerScale = true;
        requestLayout();
        searchVisibleAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                for (int i = 0; i < viewsToHide.size(); i++) {
                    View view = viewsToHide.get(i);
                    if (visible) {
                        view.setVisibility(View.INVISIBLE);
                        view.setAlpha(0);
                    } else {
                        view.setAlpha(1f);
                    }
                }

                if (visible && !ignoreTitles) {
                    if (titleTextView[0] != null) {
                        titleTextView[0].setVisibility(View.GONE);
                    }
                    if (titleTextView[1] != null) {
                        titleTextView[1].setVisibility(View.GONE);
                    }
                }

                if (avatarSearchImageView != null) {
                    if (!visible) {
                        avatarSearchImageView.setVisibility(View.GONE);
                    }
                }
            }
        });

        searchVisibleAnimator.setDuration(150).start();

        if (backButtonImageView != null) {
            Drawable drawable = backButtonImageView.getDrawable();
            if (drawable instanceof MenuDrawable) {
                MenuDrawable menuDrawable = (MenuDrawable) drawable;
                menuDrawable.setRotateToBack(true);
                menuDrawable.setRotation(visible ? 1 : 0, true);
            }
        }
    }

    public void setInterceptTouches(boolean value) {
        interceptTouches = value;
    }

    public void setInterceptTouchEventListener(View.OnTouchListener listener) {
        interceptTouchEventListener = listener;
    }

    public void setExtraHeight(int value) {
        extraHeight = value;
        if (actionMode != null) {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) actionMode.getLayoutParams();
            layoutParams.bottomMargin = extraHeight;
            actionMode.setLayoutParams(layoutParams);
        }
    }

    public void closeSearchField() {
        closeSearchField(true);
    }

    public void closeSearchField(boolean closeKeyboard) {
        if (!isSearchFieldVisible || menu == null) {
            return;
        }
        menu.closeSearchField(closeKeyboard);
    }

    public void openSearchField(String text, boolean animated) {
        if (menu == null || text == null) {
            return;
        }
        menu.openSearchField(!isSearchFieldVisible, !isSearchFieldVisible, text, animated);
    }

    public void openSearchField(boolean animated) {
        if (menu == null) {
            return;
        }
        menu.openSearchField(!isSearchFieldVisible, false, "", animated);
    }

    public void setSearchFilter(FiltersView.MediaFilterData filter) {
        if (menu != null) {
            menu.setFilter(filter);
        }
    }

    public void clearSearchFilters() {
        if (menu != null) {
            menu.clearSearchFilters();
        }
    }

    public void setSearchFieldText(String text) {
        menu.setSearchFieldText(text);
    }

    public void onSearchPressed() {
        menu.onSearchPressed();
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if (backButtonImageView != null) {
            backButtonImageView.setEnabled(enabled);
        }
        if (menu != null) {
            menu.setEnabled(enabled);
        }
        if (actionMode != null) {
            actionMode.setEnabled(enabled);
        }
    }

    @Override
    public void requestLayout() {
        if (ignoreLayoutRequest) {
            return;
        }
        super.requestLayout();
    }

    @Override
    public void onViewAdded(View child) {
        super.onViewAdded(child);
    }

    private int additionalTextLeft;

    public void setAdditionalTextLeft(int x) {
        additionalTextLeft = x;
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int actionBarHeight = getCurrentActionBarHeight();
        int actionBarHeightSpec = MeasureSpec.makeMeasureSpec(actionBarHeight, MeasureSpec.EXACTLY);

        ignoreLayoutRequest = true;
        if (actionModeTop != null) {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) actionModeTop.getLayoutParams();
            layoutParams.height = AndroidUtilities.statusBarHeight;
        }
        if (actionMode != null) {
            actionMode.setPadding(0, occupyStatusBar ? AndroidUtilities.statusBarHeight : 0, 0, 0);
        }
        ignoreLayoutRequest = false;

        setMeasuredDimension(width, actionBarHeight + (occupyStatusBar ? AndroidUtilities.statusBarHeight : 0) + extraHeight);

        int textLeft;
        if (backButtonImageView != null && backButtonImageView.getVisibility() != GONE) {
            backButtonImageView.measure(MeasureSpec.makeMeasureSpec(dp(54), MeasureSpec.EXACTLY), actionBarHeightSpec);
            textLeft = dp(AndroidUtilities.isTablet() ? 80 : 72);
        } else {
            textLeft = dp(AndroidUtilities.isTablet() ? 26 : 18);
        }
        // textLeft += additionalTextLeft;

        if (menu != null && menu.getVisibility() != GONE) {
            int menuWidth;
            boolean searchFieldIsVisible = menu.searchFieldVisible();
            if (searchFieldIsVisible && !this.isSearchFieldVisible) {
                menuWidth = MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST);
                menu.measure(menuWidth, actionBarHeightSpec);
                int itemsWidth = menu.getItemsMeasuredWidth(true);
                menuWidth = MeasureSpec.makeMeasureSpec(width - dp(menuOccupyBack ? 0 : AndroidUtilities.isTablet() ? 74 : 66) + menu.getItemsMeasuredWidth(true), MeasureSpec.EXACTLY);
                if (!isMenuOffsetSuppressed) {
                    menu.translateXItems(-itemsWidth);
                }
            } else if (isSearchFieldVisible) {
                menuWidth = MeasureSpec.makeMeasureSpec(width - dp(menuOccupyBack ? 0 : AndroidUtilities.isTablet() ? 74 : 66), MeasureSpec.EXACTLY);
                if (!isMenuOffsetSuppressed) {
                    menu.translateXItems(0);
                }
            } else {
                menuWidth = MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST);
                if (!isMenuOffsetSuppressed) {
                    menu.translateXItems(0);
                }
            }
            menu.measure(menuWidth, actionBarHeightSpec);

        }

        for (int i = 0; i < 2; i++) {
            if (titleTextView[0] != null && titleTextView[0].getVisibility() != GONE || subtitleTextView != null && subtitleTextView.getVisibility() != GONE) {
                // A centred title assumes a fixed 120dp of chrome. When the
                // menu is wider than that - which happens once the stories
                // avatar joins it - the title runs into the buttons and gets
                // shoved off to one side. Reserve whatever the menu really
                // takes, on both sides so the text stays centred.
                int meeroReserve = dp(120);
                if (isCentered() && menu != null) {
                    meeroReserve = Math.max(meeroReserve, menu.getMeasuredWidth() * 2 + dp(24));
                }
                int availableWidth = isCentered() ? (width - meeroReserve) : width - (menu != null ? menu.getMeasuredWidth() : 0) - dp(16) - textLeft - titleRightMargin;
                availableWidth = Math.max(availableWidth, 0);

                if (((fromBottom && i == 0) || (!fromBottom && i == 1)) && overlayTitleAnimation && titleAnimationRunning) {
                    titleTextView[i].setTextSize(glassMode ? 17 : !AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 18 : 20);
                } else {
                    if (titleTextView[0] != null && titleTextView[0].getVisibility() != GONE && subtitleTextView != null && subtitleTextView.getVisibility() != GONE) {
                        if (titleTextView[i] != null) {
                            titleTextView[i].setTextSize(glassMode ? 17 : AndroidUtilities.isTablet() ? 20 : 18);
                        }
                        subtitleTextView.setTextSize(AndroidUtilities.isTablet() ? 16 : 14);
                        if (additionalSubtitleTextView != null) {
                            additionalSubtitleTextView.setTextSize(AndroidUtilities.isTablet() ? 16 : 14);
                        }
                    } else {
                        if (titleTextView[i] != null && titleTextView[i].getVisibility() != GONE) {
                            titleTextView[i].setTextSize(glassMode ? 17 : !AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 18 : 20);
                        }
                        if (subtitleTextView != null && subtitleTextView.getVisibility() != GONE) {
                            subtitleTextView.setTextSize(!AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 14 : 16);
                        }
                        if (additionalSubtitleTextView != null) {
                            additionalSubtitleTextView.setTextSize(!AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 14 : 16);
                        }
                    }
                }

                if (titleTextView[i] != null && titleTextView[i].getVisibility() != GONE) {
                    titleTextView[i].measure(MeasureSpec.makeMeasureSpec(availableWidth, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(dp(24) + titleTextView[i].getPaddingTop() + titleTextView[i].getPaddingBottom(), MeasureSpec.AT_MOST));
                    if (centerScale) {
                        CharSequence text = titleTextView[i].getText();
                        titleTextView[i].setPivotX(titleTextView[i].getTextPaint().measureText(text, 0, text.length()) / 2f);
                        titleTextView[i].setPivotY((dp(24) >> 1));
                    } else {
                        titleTextView[i].setPivotX(0);
                        titleTextView[i].setPivotY(0);
                    }
                }
                if (subtitleTextView != null && subtitleTextView.getVisibility() != GONE) {
                    // MeeroX: a centred subtitle is laid out around the bar's
                    // midpoint using its measured width, so AT_MOST lets a long
                    // string - "Proxy server setup" and the like - measure wider
                    // than the gap between the buttons and slide underneath
                    // them. Pinning the width to the same reserve the title
                    // uses keeps it inside that gap and ellipsised instead.
                    final int subtitleSpec = isCentered()
                            ? MeasureSpec.makeMeasureSpec(availableWidth, MeasureSpec.EXACTLY)
                            : MeasureSpec.makeMeasureSpec(availableWidth, MeasureSpec.AT_MOST);
                    subtitleTextView.measure(subtitleSpec, MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.AT_MOST));
                }
                if (additionalSubTitleOverlayContainer != null) {
                    // Same reserve as the title, so a long status string is
                    // ellipsised inside the gap between the buttons rather
                    // than measuring wide enough to slide under them.
                    additionalSubTitleOverlayContainer.measure(
                            MeasureSpec.makeMeasureSpec(availableWidth, isCentered() ? MeasureSpec.EXACTLY : MeasureSpec.AT_MOST),
                            MeasureSpec.makeMeasureSpec(height, MeasureSpec.AT_MOST));
                }
                if (additionalSubtitleTextView != null && additionalSubtitleTextView.getVisibility() != GONE) {
                    additionalSubtitleTextView.measure(MeasureSpec.makeMeasureSpec(availableWidth, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.AT_MOST));
                }
            }
        }

        if (avatarSearchImageView != null) {
            avatarSearchImageView.measure(
                MeasureSpec.makeMeasureSpec(dp(42), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(dp(42), MeasureSpec.EXACTLY)
            );
        }

        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE || child == titleTextView[0] || child == titleTextView[1] || child == additionalSubTitleOverlayContainer || child == subtitleTextView || child == menu || child == backButtonImageView || child == additionalSubtitleTextView || child == avatarSearchImageView) {
                continue;
            }
            measureChildWithMargins(child, widthMeasureSpec, 0, MeasureSpec.makeMeasureSpec(getMeasuredHeight(), MeasureSpec.EXACTLY), 0);
        }
    }

    public void setMenuOffsetSuppressed(boolean menuOffsetSuppressed) {
        isMenuOffsetSuppressed = menuOffsetSuppressed;
    }

    int prevWidth;

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int additionalTop = occupyStatusBar ? AndroidUtilities.statusBarHeight : 0;
        if (prevWidth != getMeasuredWidth()) {
            prevWidth = getMeasuredWidth();
            checkAvatarContainerWidth(animatorAvatarContainerWidth.isAnimating());
        }

        int textLeft;
        if (backButtonImageView != null && backButtonImageView.getVisibility() != GONE) {
            backButtonImageView.layout(0, additionalTop, backButtonImageView.getMeasuredWidth(), additionalTop + backButtonImageView.getMeasuredHeight());
            textLeft = glassMode ? dp(76) : dp(AndroidUtilities.isTablet() ? 80 : 72);
        } else {
            textLeft = glassMode ? dp(24) : dp(AndroidUtilities.isTablet() ? 26 : 18);
        }
        textLeft += additionalTextLeft;

        if (menu != null && menu.getVisibility() != GONE) {
            int menuLeft = menu.searchFieldVisible() ? dp(menuOccupyBack ? 0 : AndroidUtilities.isTablet() ? 74 : 66) : (getMeasuredWidth()) - menu.getMeasuredWidth();
            menu.layout(menuLeft, additionalTop, menuLeft + menu.getMeasuredWidth(), additionalTop + menu.getMeasuredHeight());
        }

        for (int i = 0; i < 2; i++) {
            if (titleTextView[i] != null && titleTextView[i].getVisibility() != GONE) {
                int textTop;
                if (((fromBottom && i == 0) || (!fromBottom && i == 1)) && overlayTitleAnimation && titleAnimationRunning) {
                    textTop = (getCurrentActionBarHeight() - titleTextView[i].getTextHeight()) / 2;
                } else {
                    if ((subtitleTextView != null && subtitleTextView.getVisibility() != GONE)) {
                        textTop = (getCurrentActionBarHeight() / 2 - titleTextView[i].getTextHeight()) / 2 + dp(2) + dp(!AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 2 : 3);
                    } else {
                        textTop = (getCurrentActionBarHeight() - titleTextView[i].getTextHeight()) / 2;
                    }
                }

                if (isCentered()) {
                    // MeeroX: a plain centred title.
                    //
                    // This used to be nudged right by a width the stories row
                    // reported, to centre the pair. That was wrong twice over:
                    // the row is only beside the title once it has collapsed,
                    // and by then DialogsActivity has faded this view out and
                    // the stories cell is drawing its own label instead. So the
                    // nudge only ever moved an invisible view, while costing a
                    // re-layout on every frame of the collapse. The grouping is
                    // done inside DialogStoriesCell now, where both halves can
                    // actually be measured.
                    final int meeroCx = getMeasuredWidth() / 2;
                    titleTextView[i].layout(meeroCx - titleTextView[i].getMeasuredWidth() / 2, additionalTop + textTop - titleTextView[i].getPaddingTop(), meeroCx + titleTextView[i].getMeasuredWidth() / 2, additionalTop + textTop + titleTextView[i].getTextHeight() - titleTextView[i].getPaddingTop() + titleTextView[i].getPaddingBottom());
                } else {
                    titleTextView[i].layout(textLeft, additionalTop + textTop - titleTextView[i].getPaddingTop(), textLeft + titleTextView[i].getMeasuredWidth(), additionalTop + textTop + titleTextView[i].getTextHeight() - titleTextView[i].getPaddingTop() + titleTextView[i].getPaddingBottom());
                }

            }
        }
        if (additionalSubTitleOverlayContainer != null) {
            int textTop = getCurrentActionBarHeight() / 2 + (getCurrentActionBarHeight() / 2 - additionalSubTitleOverlayContainer.getMeasuredHeight()) / 2 - dp(2);
            // MeeroX: this container carries the connection status - "Proxy
            // server setup" and friends - and was the one line in the header
            // still pinned to textLeft. The title and the plain subtitle both
            // honour isCentered(), so with a centred header the status sat
            // alone on the left and ran under the third button. Centre it the
            // same way they are.
            if (isCentered()) {
                final int cw = additionalSubTitleOverlayContainer.getMeasuredWidth();
                final int cl = getMeasuredWidth() / 2 - cw / 2;
                additionalSubTitleOverlayContainer.layout(cl, additionalTop + textTop, cl + cw, additionalTop + textTop + additionalSubTitleOverlayContainer.getMeasuredHeight());
            } else {
                additionalSubTitleOverlayContainer.layout(textLeft, additionalTop + textTop, textLeft + additionalSubTitleOverlayContainer.getMeasuredWidth(), additionalTop + textTop + additionalSubTitleOverlayContainer.getMeasuredHeight());
            }
        }
        if (subtitleTextView != null && subtitleTextView.getVisibility() != GONE) {
            int textTop = getCurrentActionBarHeight() / 2 + (getCurrentActionBarHeight() / 2 - subtitleTextView.getTextHeight()) / 2 - dp(2);

            if (isCentered()) {
                subtitleTextView.layout(getMeasuredWidth() / 2 - subtitleTextView.getMeasuredWidth() / 2, additionalTop + textTop, getMeasuredWidth() / 2 + subtitleTextView.getMeasuredWidth() / 2, additionalTop + textTop + subtitleTextView.getTextHeight());
            } else {
                subtitleTextView.layout(textLeft, additionalTop + textTop, textLeft + subtitleTextView.getMeasuredWidth(), additionalTop + textTop + subtitleTextView.getTextHeight());
            }

        }

        if (additionalSubtitleTextView != null && additionalSubtitleTextView.getVisibility() != GONE) {
            int textTop = getCurrentActionBarHeight() / 2 + (getCurrentActionBarHeight() / 2 - additionalSubtitleTextView.getTextHeight()) / 2 - dp(!AndroidUtilities.isTablet() && getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 1 : 1);

            if (isCentered()) {
                additionalSubtitleTextView.layout(getMeasuredWidth() / 2 - additionalSubtitleTextView.getMeasuredWidth() / 2, additionalTop + textTop, getMeasuredWidth() / 2 + additionalSubtitleTextView.getMeasuredWidth() / 2, additionalTop + textTop + additionalSubtitleTextView.getTextHeight());
            } else {
                additionalSubtitleTextView.layout(textLeft, additionalTop + textTop, textLeft + additionalSubtitleTextView.getMeasuredWidth(), additionalTop + textTop + additionalSubtitleTextView.getTextHeight());
            }

        }

        if (avatarSearchImageView != null) {
            avatarSearchImageView.layout(
                dp(56 + 8),
                additionalTop + (getCurrentActionBarHeight() - avatarSearchImageView.getMeasuredHeight()) / 2,
                dp(56 + 8) + avatarSearchImageView.getMeasuredWidth(),
                additionalTop + (getCurrentActionBarHeight() + avatarSearchImageView.getMeasuredHeight()) / 2
            );
        }

        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE || child == titleTextView[0] || child == titleTextView[1] || child == additionalSubTitleOverlayContainer || child == subtitleTextView || child == menu || child == backButtonImageView || child == additionalSubtitleTextView || child == avatarSearchImageView) {
                continue;
            }

            LayoutParams lp = (LayoutParams) child.getLayoutParams();

            int width = child.getMeasuredWidth();
            int height = child.getMeasuredHeight();
            int childLeft;
            int childTop;

            int gravity = lp.gravity;
            if (gravity == -1) {
                gravity = Gravity.TOP | Gravity.LEFT;
            }

            final int absoluteGravity = gravity & Gravity.HORIZONTAL_GRAVITY_MASK;
            final int verticalGravity = gravity & Gravity.VERTICAL_GRAVITY_MASK;

            switch (absoluteGravity & Gravity.HORIZONTAL_GRAVITY_MASK) {
                case Gravity.CENTER_HORIZONTAL:
                    childLeft = (getMeasuredWidth() - width) / 2 + lp.leftMargin - lp.rightMargin;
                    break;
                case Gravity.RIGHT:
                    childLeft = getMeasuredWidth() - width - lp.rightMargin;
                    break;
                case Gravity.LEFT:
                default:
                    childLeft = lp.leftMargin;
            }

            switch (verticalGravity) {
                case Gravity.CENTER_VERTICAL:
                    childTop = (bottom - top - height) / 2 + lp.topMargin - lp.bottomMargin;
                    break;
                case Gravity.BOTTOM:
                    childTop = (bottom - top) - height - lp.bottomMargin;
                    break;
                default:
                    childTop = lp.topMargin;
            }
            child.layout(childLeft, childTop, childLeft + width, childTop + height);
        }
    }

    public void onMenuButtonPressed() {
        if (isActionModeShowed()) {
            return;
        }
        if (menu != null) {
            menu.onMenuButtonPressed();
        }
    }

    public void onResume() {
        resumed = true;
        updateAttachState();
    }

    protected void onPause() {
        resumed = false;
        updateAttachState();
        if (menu != null) {
            menu.hideAllPopupMenus();
        }
    }

    public void setAllowOverlayTitle(boolean value) {
        allowOverlayTitle = value;
    }

    public void setTitleActionRunnable(Runnable action) {
        lastRunnable = titleActionRunnable = action;
    }

    boolean overlayTitleAnimationInProgress;

    /**
     * MeeroX: the spinner shown beside a connection-state title.
     *
     * Held rather than rebuilt so its rotation survives a state change - the
     * connection can move between Connecting, Waiting and Updating several
     * times in a row, and a fresh drawable each time would visibly reset.
     */
    private tw.nekomimi.nekogram.MeeroConnectingDrawable meeroConnectingDrawable;

    /** MeeroX: rides on the iOS loading indicator switch. */
    private static boolean meeroConnectingSpinnerEnabled() {
        try {
            return tw.nekomimi.nekogram.MeeroConnectingDrawable.enabled();
        } catch (Throwable ignore) {
            return false;
        }
    }

    /**
     * MeeroX: puts the connecting ring on a title view, or takes it off.
     *
     * The gap is set to 8dp rather than the title's usual 4dp: the ellipsis
     * animating at the end of the text is itself three round dots, and at 4dp
     * the ring reads as a fourth one in the same run instead of as a separate
     * indicator.
     *
     * setLeftDrawable is a no-op when the drawable is already the one set, so
     * calling this on every state change is cheap and does not restart the
     * animation.
     */
    private void meeroApplyConnectingSpinner(SimpleTextView view) {
        if (view == null) {
            return;
        }
        if (!meeroConnectingSpinnerEnabled()) {
            return;
        }
        if (meeroConnectingDrawable == null) {
            meeroConnectingDrawable = new tw.nekomimi.nekogram.MeeroConnectingDrawable();
        }
        meeroConnectingDrawable.setColor(view.getTextColor());
        view.setDrawablePadding(dp(8));
        view.setLeftDrawableOutside(true);
        view.setLeftDrawable(meeroConnectingDrawable);
    }

    /**
     * MeeroX: removes the ring when the title stops being a connection state.
     *
     * Without this the ring would stay behind on a normal title - the overlay
     * is cleared by passing a null title, which restores the text but leaves
     * whatever was in the left slot.
     */
    private void meeroClearConnectingSpinner(SimpleTextView view) {
        if (view == null || meeroConnectingDrawable == null) {
            return;
        }
        if (view.getLeftDrawable() == meeroConnectingDrawable) {
            view.setLeftDrawable((Drawable) null);
            view.setLeftDrawableOutside(false);
            view.setDrawablePadding(dp(4));
        }
    }

    public void setTitleOverlayText(String title, int titleId, Runnable action) {
        if (!allowOverlayTitle || parentFragment.parentLayout == null) {
            return;
        }
        overlayTitleToSet[0] = title;
        overlayTitleToSet[1] = titleId;
        overlayTitleToSet[2] = action;
        if (overlayTitleAnimationInProgress) {
            return;
        }
        if (lastOverlayTitle == null && title == null || (lastOverlayTitle != null && lastOverlayTitle.equals(title))) {
            return;
        }
        lastOverlayTitle = title;

        if (additionalSubTitleOverlayContainer != null) {
            final CharSequence textToSet;
            if (titleId == R.string.ConnectingToProxyWithDots) {
                textToSet = AndroidUtilities.replaceArrows(getString(R.string.TitleSetupProxy), true, dp(8f / 3f), dp(2));
            } else {
                textToSet = null;
            }
            additionalSubTitleOverlayContainer.setText(textToSet, true);
        }


        CharSequence textToSet = title != null ? LocaleController.getString(title, titleId) : lastTitle;
        Drawable rightDrawableToSet = title != null ? null : lastRightDrawable;
        boolean ellipsize = false;
        if (title != null) {
            int index = TextUtils.indexOf(textToSet, "...");
            if (index >= 0) {
                SpannableString spannableString = SpannableString.valueOf(textToSet);
                ellipsizeSpanAnimator.wrap(spannableString, index);
                textToSet = spannableString;
                ellipsize = true;
            }
            // MeeroX: iOS puts a turning ring beside the connection state.
            // Android animates the three dots and leaves it at that, which
            // reads as a sentence rather than as work in progress.
            //
            // The ring goes in the LEFT slot, not the right one. The first
            // attempt used setRightDrawable and the ring never appeared: all
            // three of SimpleTextView's right-hand draw paths position it at
            // textOffsetX + textWidth + drawablePadding, which for a title as
            // long as "Waiting for network..." lands past the measured width,
            // and onMeasure only reserves room for a right drawable when
            // rightDrawableOutside is set - which it was not, so the glyph was
            // clipped away entirely.
            //
            // leftDrawableOutside has neither problem: onMeasure subtracts its
            // width on the same line, onDraw places it at x = 0 after the
            // canvas is restored, and textOffsetX is shifted to make room. It
            // also puts the ring exactly where it is wanted - the title draws
            // from the physical left, so the ellipsis animating at the end of
            // the Arabic text sits at that edge too, and the ring lands right
            // next to it.
            //
            // Created once and reused: a new instance per state change would
            // restart the sweep and make the ring stutter as the connection
            // flips between Connecting, Waiting and Updating.
            //
            // Applied further down, once the title view exists and has had its
            // own setDrawablePadding call - doing it here would be undone by
            // that call, and titleTextView[0] may still be null at this point.
        }
        titleOverlayShown = title != null;
        if ((textToSet != null && titleTextView[0] == null) || getMeasuredWidth() == 0 || (titleTextView[0] != null && titleTextView[0].getVisibility() != View.VISIBLE)) {
            createTitleTextView(0);
            if (supportsHolidayImage) {
                titleTextView[0].invalidate();
                invalidate();
            }
            titleTextView[0].setText(textToSet);
            titleTextView[0].setDrawablePadding(dp(4));
            titleTextView[0].setRightDrawable(rightDrawableToSet);
            titleTextView[0].setRightDrawableOnClick(rightDrawableOnClickListener);
            // MeeroX: after setDrawablePadding above, which would otherwise
            // overwrite the wider gap the ring needs.
            if (title != null) {
                meeroApplyConnectingSpinner(titleTextView[0]);
            } else {
                meeroClearConnectingSpinner(titleTextView[0]);
            }
            if (rightDrawableToSet instanceof AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) {
                ((AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) rightDrawableToSet).setParentView(titleTextView[0]);
            }
            if (ellipsize) {
                ellipsizeSpanAnimator.addView(titleTextView[0]);
            } else {
                ellipsizeSpanAnimator.removeView(titleTextView[0]);
            }
        } else if (titleTextView[0] != null) {
            titleTextView[0].animate().cancel();
            if (titleTextView[1] != null) {
                titleTextView[1].animate().cancel();
            }
            if (titleTextView[1] == null) {
                createTitleTextView(1);
            }
            titleTextView[1].setText(textToSet);
            titleTextView[1].setDrawablePadding(dp(4));
            titleTextView[1].setRightDrawable(rightDrawableToSet);
            titleTextView[1].setRightDrawableOnClick(rightDrawableOnClickListener);
            // MeeroX: this is the crossfade path - the incoming title is
            // built in slot 1 and the two are swapped once it finishes, so
            // the ring has to be put on whichever view is arriving, and
            // taken off it when the arriving title is an ordinary one.
            if (title != null) {
                meeroApplyConnectingSpinner(titleTextView[1]);
            } else {
                meeroClearConnectingSpinner(titleTextView[1]);
            }
            if (rightDrawableToSet instanceof AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) {
                ((AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) rightDrawableToSet).setParentView(titleTextView[1]);
            }
            if (ellipsize) {
                ellipsizeSpanAnimator.addView(titleTextView[1]);
            }
            overlayTitleAnimationInProgress = true;
            SimpleTextView tmp = titleTextView[1];
            titleTextView[1] = titleTextView[0];
            titleTextView[0] = tmp;
            titleTextView[0].setAlpha(0);
            titleTextView[0].setTranslationY(-dp(20));
            titleTextView[0].animate()
                    .alpha(adaptiveBackgroundHideTitle ? 1.0f - onTopAnimated : 1f)
                    .translationY(0)
                    .setDuration(220).start();
            ViewPropertyAnimator animator = titleTextView[1].animate()
                    .alpha(0);
            if (subtitleTextView == null) {
                animator.translationY(dp(20));
            } else {
                animator.scaleY(0.7f).scaleX(0.7f);
            }
            requestLayout();
            centerScale = true;
            animator.setDuration(220).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    if (titleTextView[1] != null && titleTextView[1].getParent() != null) {
                        ViewGroup viewGroup = (ViewGroup) titleTextView[1].getParent();
                        viewGroup.removeView(titleTextView[1]);
                    }
                    ellipsizeSpanAnimator.removeView(titleTextView[1]);
                    titleTextView[1] = null;
                    overlayTitleAnimationInProgress = false;
                    setTitleOverlayText((String) overlayTitleToSet[0], (int) overlayTitleToSet[1], (Runnable) overlayTitleToSet[2]);
                }
            }).start();
        }
        titleActionRunnable = action != null ? action : lastRunnable;
    }

    public boolean isSearchFieldVisible() {
        return isSearchFieldVisible;
    }

    public void setOccupyStatusBar(boolean value) {
        occupyStatusBar = value;
        if (actionMode != null) {
            actionMode.setPadding(0, occupyStatusBar ? AndroidUtilities.statusBarHeight : 0, 0, 0);
        }
    }

    public boolean getOccupyStatusBar() {
        return occupyStatusBar;
    }

    public void setItemsBackgroundColor(int color, boolean isActionMode) {
        if (isActionMode) {
            itemsActionModeBackgroundColor = color;
            if (actionModeVisible) {
                if (backButtonImageView != null) {
                    backButtonImageView.setBackgroundDrawable(Theme.createSelectorDrawable(itemsActionModeBackgroundColor));
                }
            }
            if (actionMode != null) {
                actionMode.updateItemsBackgroundColor();
            }
        } else {
            itemsBackgroundColor = color;
            if (backButtonImageView != null) {
                backButtonImageView.setBackgroundDrawable(Theme.createSelectorDrawable(itemsBackgroundColor));
            }
            if (menu != null) {
                menu.updateItemsBackgroundColor();
            }
        }
    }

    public void setItemsColor(int color, boolean isActionMode) {
        if (isActionMode) {
            itemsActionModeColor = color;
            if (actionMode != null) {
                actionMode.updateItemsColor();
            }
            if (backButtonImageView != null) {
                Drawable drawable = backButtonImageView.getDrawable();
                if (drawable instanceof BackDrawable) {
                    ((BackDrawable) drawable).setRotatedColor(color);
                } else if (drawable instanceof BitmapDrawable || drawable instanceof VectorDrawable) {
                    backButtonImageView.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                }
            }
        } else {
            itemsColor = color;
            if (backButtonImageView != null) {
                if (itemsColor != 0) {
                    Drawable drawable = backButtonImageView.getDrawable();
                    if (drawable instanceof BackDrawable) {
                        ((BackDrawable) drawable).setColor(color);
                    } else if (drawable instanceof MenuDrawable) {
                        ((MenuDrawable) drawable).setIconColor(color);
                    } else if (drawable instanceof BitmapDrawable || drawable instanceof VectorDrawable) {
                        backButtonImageView.setColorFilter(new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
                    }
                }
            }
            if (menu != null) {
                menu.updateItemsColor();
            }
        }

        if (backButtonImageView != null && mAlwaysApplyColorFilterToBackButton) {
            backButtonImageView.setColorFilter(new PorterDuffColorFilter(itemsColor, PorterDuff.Mode.SRC_IN));
        }
    }

    public void setCastShadows(boolean value) {
        if (castShadows != value && getParent() instanceof View) {
            ((View) getParent()).invalidate();
            invalidate();
        }
        castShadows = value;
    }

    public void setShadowAlpha(int alpha) {
        if (this.shadowAlpha == alpha) return;
        if (getParent() instanceof View) {
            ((View) getParent()).invalidate();
            invalidate();
        }
        this.shadowAlpha = alpha;
    }

    public int getShadowAlpha() {
        return shadowAlpha;
    }

    public boolean getCastShadows() {
        return castShadows;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (chatAvatarContainer != null && glassMode) {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                final int x = (int) ev.getX();
                final int y = (int) ev.getY();
                View child = findChildUnder(this, x, y, chatAvatarContainer);
                if (child == null) {
                    child = findChildUnder(this, x, y, null);
                }

                boolean contains = false;
                contains |= glassDrawable != null && glassDrawable.getBounds().contains(x, y);
                if (child != null && child != chatAvatarContainer) {
                    contains |= glassDrawableBack != null && glassDrawableBack.getBounds().contains(x, y);
                    contains |= glassDrawableMenu != null && glassDrawableMenu.getBounds().contains(x, y);
                }

                if (!contains) {
                    return false;
                }
            }
        }

        return super.dispatchTouchEvent(ev);
    }

    public static View findChildUnder(ViewGroup parent, float x, float y, View exclude) {
        for (int i = parent.getChildCount() - 1; i >= 0; i--) {
            View child = parent.getChildAt(i);

            if (child.getVisibility() != View.VISIBLE || child == exclude) continue;

            if (x >= child.getX() && x <= (child.getX() + child.getWidth())
                    && y >= child.getTop() && y <= child.getBottom()) {
                return child;
            }
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (forceSkipTouches) {
            return false;
        }
        return super.onTouchEvent(event) || interceptTouches;
    }

    public static int getCurrentActionBarHeight() {
        if (AndroidUtilities.displaySize.x > AndroidUtilities.displaySize.y) {
            return dp(48);
        } else {
            return dp(56);
        }
    }

    public void setTitleAnimated(CharSequence title, boolean fromBottom, long duration) {
        setTitleAnimated(title, fromBottom, duration, null);
    }

    public void setTitleAnimated(CharSequence title, boolean fromBottom, long duration, Interpolator interpolator) {
        if (titleTextView[0] == null || title == null) {
            setTitle(title);
            return;
        }
        boolean crossfade = overlayTitleAnimation && !TextUtils.isEmpty(subtitle);
        if (crossfade) {
            if (subtitleTextView.getVisibility() != View.VISIBLE) {
                subtitleTextView.setVisibility(View.VISIBLE);
                subtitleTextView.setAlpha(0);
            }
            subtitleTextView.animate().alpha(fromBottom ? 0 : 1f).setDuration(220).start();
        }
        if (titleTextView[1] != null) {
            if (titleTextView[1].getParent() != null) {
                ViewGroup viewGroup = (ViewGroup) titleTextView[1].getParent();
                viewGroup.removeView(titleTextView[1]);
            }
            titleTextView[1] = null;
        }
        titleTextView[1] = titleTextView[0];
        titleTextView[0] = null;
        setTitle(title);
        this.fromBottom = fromBottom;
        titleTextView[0].setAlpha(0);
        if (!crossfade) {
            titleTextView[0].setTranslationY(fromBottom ? dp(20) : -dp(20));
        }
        ViewPropertyAnimator a1 = titleTextView[0].animate().alpha(1f).translationY(0).setDuration(duration);
        if (interpolator != null) {
            a1.setInterpolator(interpolator);
        }
        a1.start();

        titleAnimationRunning = true;
        ViewPropertyAnimator a = titleTextView[1].animate().alpha(0);
        if (!crossfade) {
            a.translationY(fromBottom ? -dp(20) : dp(20));
        }
        if (interpolator != null) {
            a.setInterpolator(interpolator);
        }
        a.setDuration(duration).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (titleTextView[1] != null && titleTextView[1].getParent() != null) {
                    ViewGroup viewGroup = (ViewGroup) titleTextView[1].getParent();
                    viewGroup.removeView(titleTextView[1]);
                }
                titleTextView[1] = null;
                titleAnimationRunning = false;

                if (crossfade && fromBottom) {
                    subtitleTextView.setVisibility(View.GONE);
                }

                requestLayout();
            }
        }).start();
        requestLayout();
    }

    // NagramX: use folder name as title
    public void setTitleAnimatedX(CharSequence title, Drawable rightDrawable, boolean forward, long duration) {
        if (titleTextView[0] == null || title == null) {
            setTitle(title, rightDrawable);
            return;
        }
        if (titleTextView[1] != null) {
            if (titleTextView[1].getParent() != null) {
                ViewGroup viewGroup = (ViewGroup) titleTextView[1].getParent();
                viewGroup.removeView(titleTextView[1]);
            }
            titleTextView[1] = null;
        }
        titleTextView[1] = titleTextView[0];
        titleTextView[0] = null;
        setTitle(title, rightDrawable);
        titleTextView[0].setAlpha(0);
        titleTextView[0].setTranslationX(forward ? AndroidUtilities.dp(20) : -AndroidUtilities.dp(20));
        titleTextView[0].animate().alpha(1f).translationX(0).setDuration(duration).start();

        titleAnimationRunning = true;
        ViewPropertyAnimator a = titleTextView[1].animate().alpha(0);
        a.translationX(forward ? -AndroidUtilities.dp(20) : AndroidUtilities.dp(20));
        a.setDuration(duration).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (titleTextView[1] != null && titleTextView[1].getParent() != null) {
                    ViewGroup viewGroup = (ViewGroup) titleTextView[1].getParent();
                    viewGroup.removeView(titleTextView[1]);
                }
                titleTextView[1] = null;
                titleAnimationRunning = false;

                requestLayout();
            }
        }).start();
        requestLayout();
    }

    @Override
    public boolean hasOverlappingRendering() {
        return false;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        updateAttachState();
        if (actionModeVisible) {
            final int color = actionModeColor == 0 ? actionBarColor : actionModeColor;
            if (color == 0 || glassMode) {
                NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.needCheckSystemBarColors);
            } else if (ColorUtils.calculateLuminance(color) < 0.7f) {
                AndroidUtilities.setLightStatusBar((Activity) getContext(), false);
            } else {
                AndroidUtilities.setLightStatusBar((Activity) getContext(), true);
            }
        }
        if (lastRightDrawable instanceof AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) {
            ((AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) lastRightDrawable).setParentView(titleTextView[0]);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        attached = false;
        updateAttachState();
        if (actionModeVisible) {
            if (actionBarColor == 0 || actionModeColor == 0 || glassMode) {
                NotificationCenter.getGlobalInstance().postNotificationName(NotificationCenter.needCheckSystemBarColors);
            } else {
                if (ColorUtils.calculateLuminance(actionBarColor) < 0.7f) {
                    AndroidUtilities.setLightStatusBar((Activity) getContext(), false);
                } else {
                    AndroidUtilities.setLightStatusBar((Activity) getContext(), true);
                }
            }
        }
        if (lastRightDrawable instanceof AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) {
            ((AnimatedEmojiDrawable.SwapAnimatedEmojiDrawable) lastRightDrawable).setParentView(null);
        }
    }

    private void updateAttachState() {
        boolean attachState = attached && resumed;
        if (this.attachState != attachState) {
            this.attachState = attachState;
            if (attachState) {
                ellipsizeSpanAnimator.onAttachedToWindow();
            } else {
                ellipsizeSpanAnimator.onDetachedFromWindow();
            }
        }
    }

    public ActionBarMenu getActionMode() {
        return actionMode;
    }

    public void setOverlayTitleAnimation(boolean ovelayTitleAnimation) {
        this.overlayTitleAnimation = ovelayTitleAnimation;
    }

    public void beginDelayedTransition() {
        if (!LocaleController.isRTL) {
            TransitionSet transitionSet = new TransitionSet();
            transitionSet.setOrdering(TransitionSet.ORDERING_TOGETHER);
            transitionSet.addTransition(new Fade());
            transitionSet.addTransition(new ChangeBounds() {


                public void captureStartValues(TransitionValues transitionValues) {
                    super.captureStartValues(transitionValues);
                    if (transitionValues.view instanceof SimpleTextView) {
                        float textSize = ((SimpleTextView) transitionValues.view).getTextPaint().getTextSize();
                        transitionValues.values.put("text_size", textSize);
                    }
                }

                public void captureEndValues(TransitionValues transitionValues) {
                    super.captureEndValues(transitionValues);
                    if (transitionValues.view instanceof SimpleTextView) {
                        float textSize = ((SimpleTextView) transitionValues.view).getTextPaint().getTextSize();
                        transitionValues.values.put("text_size", textSize);
                    }
                }

                @Override
                public Animator createAnimator(ViewGroup sceneRoot, TransitionValues startValues, TransitionValues endValues) {
                    if (startValues != null && startValues.view instanceof SimpleTextView) {
                        AnimatorSet animatorSet = new AnimatorSet();
                        if (startValues != null && endValues != null) {
                            Animator animator = super.createAnimator(sceneRoot, startValues, endValues);
                            float s = (float) startValues.values.get("text_size") / (float) endValues.values.get("text_size");
                            startValues.view.setScaleX(s);
                            startValues.view.setScaleY(s);
                            if (animator != null) {
                                animatorSet.playTogether(animator);
                            }
                        }
                        animatorSet.playTogether(ObjectAnimator.ofFloat(startValues.view, SCALE_X, 1f));
                        animatorSet.playTogether(ObjectAnimator.ofFloat(startValues.view, SCALE_Y, 1f));
                        animatorSet.addListener(new AnimatorListenerAdapter() {

                            @Override
                            public void onAnimationStart(Animator animation) {
                                super.onAnimationStart(animation);
                                startValues.view.setLayerType(LAYER_TYPE_HARDWARE, null);
                            }

                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                startValues.view.setLayerType(LAYER_TYPE_NONE, null);
                            }
                        });
                        return animatorSet;
                    } else {
                        return super.createAnimator(sceneRoot, startValues, endValues);
                    }
                }
            });
            centerScale = false;
            transitionSet.setDuration(220);
            transitionSet.setInterpolator(CubicBezierInterpolator.DEFAULT);
            TransitionManager.beginDelayedTransition(this, transitionSet);
        }
    }

    private int getThemedColor(int key) {
        return Theme.getColor(key, resourcesProvider);
    }

    public void setDrawBlurBackground(SizeNotifierFrameLayout contentView) {
        blurredBackground = true;
        this.contentView = contentView;
        contentView.blurBehindViews.add(this);
        setBackground(null);
    }

    private boolean doNotDrawChild;

    public void setSkipDrawChild(boolean skip) {
        if (doNotDrawChild != skip) {
            doNotDrawChild = skip;
            invalidate();
        }
    }

    private float searchFactor;

    public void setSearchFactor(float factor) {
        if (searchFactor != factor) {
            searchFactor = factor;
            invalidate();
        }
    }

    public void checkAvatarContainerWidth(boolean animated) {
        if (chatAvatarContainer != null) {
            final boolean hasAvatar = chatAvatarContainer.hasVisibleAvatar();
            int visualWidth = chatAvatarContainer.getVisualWidth();
            if (hasAvatar) {
                //visualWidth = Math.max(visualWidth, dp(168));
            }

            final int width = Math.min(getMeasuredWidth() - dp(6 + 46 + 6 + 6 + 46 + 6), visualWidth);
            if (animated) {
                if (animatorAvatarContainerWidth.getToFactor() != width) {
                    animatorAvatarContainerWidth.animateTo(width);
                }
            } else {
                animatorAvatarContainerWidth.forceFactor(width);
            }
            animatorAvatarContainerHasAvatar.setValue(hasAvatar, animated);
        }

        // MeeroX v254 (cherry-parity): Adaptive bubble width — target hugs the title text, animated
        if (isAdaptiveWidthSupported()) {
            int titleWidth = (int) chatAvatarContainer2.getTitleTextView().getExactWidthIncludeDrawables();
            int subtitleWidth = 0;
            if (chatAvatarContainer2.getSubtitleTextView() instanceof SimpleTextView) {
                subtitleWidth = (int) ((SimpleTextView) chatAvatarContainer2.getSubtitleTextView()).getExactWidthIncludeDrawables();
            }
            int textWidth = Math.max(titleWidth, subtitleWidth);

            // MeeroX v262: clamp to the bar itself only. The v254 clamp to the
            // menu-dependent "default" rect could shrink the capsule under the
            // text on chats with several menu icons; the pill's position now
            // follows the text, so the only real bound is the bar edges.
            int targetWidth = Math.max(dp(100), textWidth + dp(40));
            targetWidth += dp(15);
            targetWidth = Math.min(getWidth() - dp(12), targetWidth);

            if (animated) {
                if (animatorAdaptiveWidth.getToFactor() != targetWidth) {
                    animatorAdaptiveWidth.animateTo(targetWidth);
                }
            } else {
                animatorAdaptiveWidth.forceFactor(targetWidth);
            }
        }
    }

    private final FactorAnimator animatorAvatarContainerWidth = new FactorAnimator(0, this, CubicBezierInterpolator.EASE_OUT_QUINT, 380);
    private final BoolAnimator animatorAvatarContainerHasAvatar = new BoolAnimator(0, this, CubicBezierInterpolator.EASE_OUT_QUINT, 380);

    private final FactorAnimator animatorMenuItemsWidth = new FactorAnimator(0, this, CubicBezierInterpolator.EASE_OUT_QUINT, 320);
    private final BoolAnimator animatorHasMenuItems = new BoolAnimator(0, this, CubicBezierInterpolator.EASE_OUT_QUINT, 320);

    @Override
    public void onFactorChanged(int id, float factor, float fraction, FactorAnimator callee) {
        invalidate();
    }

    private int forcedMenuWidth;
    private int forcedMenuMinWidth;
    private boolean hasForcedMenuWidth;
    private boolean hasForcedMenuMinWidth;

    public void setForcedMenuWidth(int width) {
        hasForcedMenuWidth = true;
        if (forcedMenuWidth != width) {
            forcedMenuWidth = width;
            invalidate();
        }
    }

    public void setForcedMenuMinWidth(int width) {
        hasForcedMenuMinWidth = true;
        if (forcedMenuMinWidth != width) {
            forcedMenuMinWidth = width;
            invalidate();
        }
    }

    private boolean isAnimationsAllowed;

    public void checkMenuItemsWidth() {
        int defaultMenuWidth = Math.max(0, menu != null ? (int) menu.getItemsWidth() - dp(1) - dp(1) : 0);
        if (!isSearchFieldVisible && chatAvatarContainer == null && menu != null && menu.isCenteredTitle()) {
            defaultMenuWidth = Math.max(defaultMenuWidth, dp(46));
        }
        final int actionMenuWidth = Math.max(0, actionMode != null ? actionMode.getItemsWidth() - dp(1) - dp(1) : 0);
        final int searchMenuWidth = dp(46);
        final int width = /*isSearchFieldVisible ? searchMenuWidth :*/ (actionModeVisible ? actionMenuWidth : defaultMenuWidth);

        animatorHasMenuItems.setValue(width > 0, isAnimationsAllowed);
        if (animatorMenuItemsWidth.getToFactor() != width) {
            if (isAnimationsAllowed) {
                animatorMenuItemsWidth.animateTo(width);
            } else {
                animatorMenuItemsWidth.forceFactor(width);
            }
        }
    }

    public boolean doNotDrawGlassMenu;

    // MeeroX v275 (his report: with the adaptive switch OFF, the settings
    // preview's name capsule merged with the back capsule - «الكبسولة تندمج
    // مع كبسولة الرجوع»): the preview hides the real back button and draws
    // its own hand-made back capsule, so the stock pill math below thought
    // "no back element" and let the name capsule start at x=0 - sliding
    // under the back capsule. The preview reports its back capsule's RIGHT
    // edge through this hook; real chats never touch it (button visible =
    // measured zone, unchanged since v254).
    private int meeroPreviewBackZoneEndPx = -1;
    public void setMeeroPreviewBackZoneEnd(int px) {
        if (meeroPreviewBackZoneEndPx != px) {
            meeroPreviewBackZoneEndPx = px;
            invalidate();
        }
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        final int p = dp(6);
        final int s = dp(46);

        final float actionModeFactor = getActionModeFactor();
        final int menuWidthA = hasForcedMenuWidth ? forcedMenuWidth : (int) animatorMenuItemsWidth.getFactor();
        final int menuWidth = hasForcedMenuMinWidth ? Math.max((int) (forcedMenuMinWidth * (1f - searchFactor)), menuWidthA) : menuWidthA;

        final boolean hasBackButton = backButtonImageView != null && backButtonImageView.getVisibility() == View.VISIBLE;

        final int t = getHeight() - (getCurrentActionBarHeight() + s) / 2 - p;
        final int b = t + s + p * 2;

        if (glassDrawable != null && !glassOnlyBack) {
            // MeeroX v273: the alpha is animated per-frame below for the
            // adaptive pill, so always reset it for the other branches (the
            // drawable is kept and reused across frames).
            glassDrawable.setAlpha(255);
            final int menuWidthWithPadding = menuWidth + ((hasForcedMenuWidth || hasForcedMenuMinWidth) ? (menuWidth > 0 ? p : 0) : (int) (p * animatorHasMenuItems.getFloatValue()));
            final int rightOffset = lerp(menuWidthWithPadding, Math.max(menuWidthWithPadding, p + s), chatAvatarContainer == null ? 0f : 1f - animatorAvatarContainerHasAvatar.getFloatValue());

            final int leftDefault = meeroPreviewBackZoneEndPx >= 0 && chatAvatarContainer2 != null
                    // v275: capsule glass starts at the reported capsule edge
                    // (the drawable's own 6dp padding separates the two pills
                    // visually, matching the reference's touching-capsules look)
                    ? meeroPreviewBackZoneEndPx - p
                    : lerp(hasBackButton ? s + p : 0, s + p, chatAvatarContainer == null? 0f : 1f - animatorAvatarContainerHasAvatar.getFloatValue());
            final int rightDefault = getWidth() - rightOffset;
            final int widthDefault = rightDefault - leftDefault;
            final int left, right;
            if (chatAvatarContainer != null) {
                final int width = lerp(Math.min(widthDefault, (int) animatorAvatarContainerWidth.getFactor() + p * 2), widthDefault, Math.max(searchFactor, actionModeFactor));
                left = (rightDefault + leftDefault - width) / 2;
                right = left + width;

                final float translationX = left
                    - ((MarginLayoutParams)(chatAvatarContainer.getLayoutParams())).leftMargin
                    - chatAvatarContainer.getLeftPadding()
                    + p + dp(3);
                chatAvatarContainer.setTranslationX(translationX);
                chatAvatarContainer.setPivotX((chatAvatarContainer.getMeasuredWidth()) / 2f - translationX );
            } else if (isAdaptiveWidthSupported()) {
                // MeeroX v262: the pill anchors to the ACTUAL drawn title text.
                // v254's formula centered the pill between the back button and
                // the overflow menu (baseCenter = (52dp + W - menuWidth) / 2),
                // while ChatAvatarContainer left-anchors the title inside its
                // symmetric container - so the capsule drifted off the name on
                // any real chat whose menu is wider than one item, and in the
                // settings preview. Following the text kills every variable.
                int width = (int) animatorAdaptiveWidth.getFactor();
                if (width <= 0) {
                    int titleWidth = (int) chatAvatarContainer2.getTitleTextView().getExactWidthIncludeDrawables();
                    int subtitleWidth = 0;
                    if (chatAvatarContainer2.getSubtitleTextView() instanceof SimpleTextView) {
                        subtitleWidth = (int) ((SimpleTextView) chatAvatarContainer2.getSubtitleTextView()).getExactWidthIncludeDrawables();
                    }
                    width = Math.max(dp(100), Math.max(titleWidth, subtitleWidth) + dp(40));
                    width += dp(15);
                    animatorAdaptiveWidth.forceFactor(width);
                }
                width = Math.min(width, getWidth() - p * 2);
                final float textCenter = chatAvatarContainer2.getX() + chatAvatarContainer2.meeroGetTitleTextCenterX();
                final int adaptiveLeft = Math.max(p, Math.min(Math.round(textCenter - width / 2f), getWidth() - p - width));
                final int adaptiveRight = adaptiveLeft + width;
                // MeeroX v274 (his order: take the official Telegram design):
                // in official Telegram the selection bar reads as flush
                // ADJACENT capsules - count capsule, then tools capsule -
                // and the switch itself animates. v272 made this title pill
                // slide under the tools pill (glass over glass); v273's
                // fade-out left the count bare. So instead of hiding, MORPH
                // this pill with the action-mode factor from its
                // text-anchored title geometry into the stock
                // [back-pill .. menu-pill) capsule (leftDefault..rightDefault
                // already end flush with the menu zone by design): the title
                // capsule glides into the count capsule within one 200ms
                // fade - natural glass + selection animation, no overlap,
                // no bare text. The stock branches are unchanged.
                // MeeroX v277 (his report from channel search: «زجاج ما
                // يحضن الاكس ولا كل الكلمه» + his order: fix it exactly
                // like the selection tools bar): the morph below only
                // listened to actionModeFactor, so an open search left
                // this pill anchored to the now-INVISIBLE title text - the
                // typed word and the clear-X (both living in the search
                // field, which spans [searchLeft .. W]) overflowed the
                // glass. The sibling first branch (old avatar container)
                // has always morphed with Math.max(searchFactor,
                // actionModeFactor); port that input 1:1 here. searchFactor
                // is animated by ChatActivity's
                // ANIMATOR_ID_SEARCH_FIELD_VISIBILITY, so the capsule
                // glides from the title geometry into the same flush
                // [back-pill .. menu-pill) zone the selection capsule
                // lands in - hugging the whole field (word + X) with one
                // natural glide. Stock branches untouched.
                final float meeroMorphFactor = Math.max(searchFactor, actionModeFactor);
                left = Math.round(lerp(adaptiveLeft, leftDefault, meeroMorphFactor));
                right = Math.round(lerp(adaptiveRight, rightDefault, meeroMorphFactor));
            } else {
                left = leftDefault;
                right = rightDefault;
            }

            glassDrawable.setBounds(left, t, right, b);
            glassDrawable.draw(canvas);
        }
        if (glassDrawableBack != null && hasBackButton) {
            glassDrawableBack.setBounds(0, t, s + p * 2, b);
            glassDrawableBack.draw(canvas);
        }
        // MeeroX v272 (his order, «كان موجود افتراضي كان»): v263 wrongly
        // retired this glass pill while chasing the white disc. The saga's
        // real culprit turned out to be the community badge, which is dead
        // since v266/v271 - this glass chrome was innocent all along. The
        // pill is the fork's default look he remembers: the centered title
        // forces a 46dp menu width (checkMenuItemsWidth), so it backs the
        // pinned avatar's corner, and while the action mode is open it hugs
        // the selection tools. Restored in every mode; the ⋮ glyph stays
        // hidden in the centered header (v265) - only the glass returns.
        if (glassDrawableMenu != null && menuWidth > 0 && !glassOnlyBack && !doNotDrawGlassMenu) {
            glassDrawableMenu.setBounds(getWidth() - Math.max(s, menuWidth) - p * 2, t, getWidth(), b);
            glassDrawableMenu.setAlpha(hasForcedMenuWidth ? 255 : (int) (255 * animatorHasMenuItems.getFloatValue()));
            glassDrawableMenu.draw(canvas);
        }

        if (blurredBackground && actionBarColor != Color.TRANSPARENT) {
            rectTmp.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
            blurScrimPaint.setColor(actionBarColor);
            if (adaptiveBackground) {
                contentView.drawBlurRect(canvas, getY(), rectTmp, blurScrimPaint, true, 1.0f - onTopAnimated);
            } else {
                contentView.drawBlurRect(canvas, getY(), rectTmp, blurScrimPaint, true);
            }
        }

        isAnimationsAllowed = true;
        if (doNotDrawChild) {
            return;
        }

        super.dispatchDraw(canvas);
    }

    public void setForceSkipTouches(boolean forceSkipTouches) {
        this.forceSkipTouches = forceSkipTouches;
    }

    public void setDrawBackButton(boolean b) {
        this.drawBackButton = b;
        if (backButtonImageView != null) {
            backButtonImageView.invalidate();
        }
    }

    // NekoX Changes

    private StaticLayout countLayout;

    public class UnreadImageView extends AppCompatImageView {
        public UnreadImageView(Context context) {
            super(context);
        }

        private int unreadCount = 0;
        private RectF rect = new RectF();
        // MeeroX v243 (his pick - preview option 2): iPhone-red unread chip.
        // Own paint: Theme.dialogs_countPaint is shared app-wide (dialogs
        // list, folders, etc.) and must keep the accent blue.
        private final Paint meeroBadgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        @Override
        public void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (countLayout == null || unreadCount == 0)
                return;

            Paint paint = Theme.dialogs_countPaint;
            // MeeroX v243: same red Telegram-iOS draws for this chip (#FF3B30),
            // day & night; text keeps the stock white dialogs_countTextPaint.
            meeroBadgePaint.setColor(0xFFFF3B30);
            paint = meeroBadgePaint;
            String unreadCountString = unreadCount > 99 ? "99+" : Integer.toString(unreadCount);
            int countWidth = Math.max(AndroidUtilities.dp(12), (int) Math.ceil(Theme.dialogs_countTextPaint.measureText(unreadCountString)));
            int countLeft = getMeasuredWidth() - countWidth - AndroidUtilities.dp(20);
            int countTop = 0;

            int x = countLeft - AndroidUtilities.dp(5.5f);
            rect.set(x, countTop, x + countWidth + AndroidUtilities.dp(11), countTop + AndroidUtilities.dp(23));
            canvas.drawRoundRect(rect, 11.5f * AndroidUtilities.density, 11.5f * AndroidUtilities.density, paint);
            canvas.save();
            canvas.translate(countLeft, countTop + AndroidUtilities.dp(4));
            countLayout.draw(canvas);
            canvas.restore();
        }

        public void setUnread(int count) {
            if (count != unreadCount) {
                unreadCount = count;
                String countString = count > 99 ? "99+" : Integer.toString(count);
                int countWidth = count == 0 ? 0 : Math.max(AndroidUtilities.dp(12), (int) Math.ceil(Theme.dialogs_countTextPaint.measureText(countString)));
                countLayout = new StaticLayout(countString, Theme.dialogs_countTextPaint, countWidth, Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
                invalidate();
            }
        }
    }

    public void unreadBadgeSetCount(int count) {
        if (backButtonImageView != null && NekoConfig.unreadBadgeOnBackButton.Bool()) {
            backButtonImageView.setUnread(count);
        }
    }

    public void setUseContainerForTitles() {
        this.useContainerForTitles = true;
        if (titlesContainer == null) {
            titlesContainer = new FrameLayout(getContext()) {
                @Override
                protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
                    setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec));
                }

                @Override
                protected void onLayout(boolean changed, int left, int top, int right, int bottom) {

                }
            };
            addView(titlesContainer);
        }
    }

    public FrameLayout getTitlesContainer() {
        return titlesContainer;
    }

    @Override
    public void updateColors() {
        adaptive_updateColor();
        if (glassDrawable != null) {
            glassDrawable.updateColors();
        }
        if (glassDrawableMenu != null) {
            glassDrawableMenu.updateColors();
        }
        if (glassDrawableBack != null) {
            glassDrawableBack.updateColors();
        }
        if (additionalSubTitleOverlayContainer != null) {
            additionalSubTitleOverlayContainer.updateColors();
        }
    }

    private ActionBarAnimatedSubtitleOverlayContainer additionalSubTitleOverlayContainer;
    public FrameLayout createAdditionalSubTitleOverlayContainer() {
        if (additionalSubTitleOverlayContainer == null) {
            additionalSubTitleOverlayContainer = new ActionBarAnimatedSubtitleOverlayContainer(getContext(), resourcesProvider, ellipsizeSpanAnimator) {
                @Override
                public void onItemChanged(ReplaceAnimator<?> animator) {
                    super.onItemChanged(animator);
                    final float overlayVisibility = getTotalVisibility();
                    if (titlesContainer != null) {
                        titlesContainer.setTranslationY(overlayVisibility * dp(-11));
                    }
                }
            };
            additionalSubTitleOverlayContainer.setClipChildren(false);
            addView(additionalSubTitleOverlayContainer);
        }
        return additionalSubTitleOverlayContainer;
    }
    public FrameLayout getAdditionalSubTitleOverlayContainer() {
        return additionalSubTitleOverlayContainer;
    }

    private boolean adaptiveBackground, adaptiveBackgroundHideTitle;
    private int adaptive_topColorKey;
    private int adaptive_lowerColorKey;
    private boolean onTop = true;
    private float onTopAnimated = 1.0f;
    private ValueAnimator adaptive_animator;
    public void setAdaptiveBackground(RecyclerView list) {
        setAdaptiveBackground(list, false, Theme.key_windowBackgroundGray, Theme.key_actionBarDefault);
    }
    public void setAdaptiveBackground(RecyclerView list, boolean hideTitle) {
        setAdaptiveBackground(list, hideTitle, Theme.key_windowBackgroundGray, Theme.key_actionBarDefault);
    }
    public void setAdaptiveBackground(RecyclerView list, boolean hideTitle, final int topColorKey, final int lowerColorKey) {
        this.adaptive_topColorKey = topColorKey;
        this.adaptive_lowerColorKey = lowerColorKey;
        final Runnable checkScroll = () -> {
            final boolean onTop = !list.canScrollVertically(-1);
            if (ActionBar.this.onTop == onTop) return;
            if (adaptive_animator != null)
                adaptive_animator.cancel();
            adaptive_animator = ValueAnimator.ofFloat(onTopAnimated, (ActionBar.this.onTop = onTop) ? 1.0f : 0.0f);
            adaptive_animator.addUpdateListener(anm -> {
                onTopAnimated = (float) anm.getAnimatedValue();
                adaptive_updateColor();
            });
            adaptive_animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    onTopAnimated = onTop ? 1.0f : 0.0f;
                    adaptive_updateColor();
                }
            });
            adaptive_animator.setDuration(320);
            adaptive_animator.setInterpolator(CubicBezierInterpolator.EASE_OUT_QUINT);
            adaptive_animator.start();
        };
        list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                checkScroll.run();
            }
        });
        this.adaptiveBackgroundHideTitle = hideTitle;
        if (this.adaptiveBackground) {
            checkScroll.run();
        } else {
            this.adaptiveBackground = true;
            this.onTopAnimated = (this.onTop = !list.canScrollVertically(-1)) ? 1 : 0;
            adaptive_updateColor();
        }
    }
    public void setAdaptiveBackground(SectionsScrollView list) {
        setAdaptiveBackground(list, Theme.key_windowBackgroundGray, Theme.key_actionBarDefault);
    }
    public void setAdaptiveBackground(SectionsScrollView list, final int topColorKey, final int lowerColorKey) {
        this.adaptive_topColorKey = topColorKey;
        this.adaptive_lowerColorKey = lowerColorKey;
        adaptive_updateColor();
        final Runnable checkScroll = () -> {
            final boolean onTop = !list.canScrollVertically(-1);
            if (ActionBar.this.onTop == onTop) return;
            if (adaptive_animator != null)
                adaptive_animator.cancel();
            adaptive_animator = ValueAnimator.ofFloat(onTopAnimated, (ActionBar.this.onTop = onTop) ? 1.0f : 0.0f);
            adaptive_animator.addUpdateListener(anm -> {
                onTopAnimated = (float) anm.getAnimatedValue();
                adaptive_updateColor();
            });
            adaptive_animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    onTopAnimated = onTop ? 1.0f : 0.0f;
                    adaptive_updateColor();
                }
            });
            adaptive_animator.setDuration(320);
            adaptive_animator.setInterpolator(CubicBezierInterpolator.EASE_OUT_QUINT);
            adaptive_animator.start();
        };
        list.onScroll(checkScroll);
        if (this.adaptiveBackground) {
            checkScroll.run();
        } else {
            this.adaptiveBackground = true;
            this.onTopAnimated = (this.onTop = !list.canScrollVertically(-1)) ? 1 : 0;
            adaptive_updateColor();
        }
    }
    private void adaptive_updateColor() {
        if (!adaptiveBackground) return;
        if (adaptiveBackgroundHideTitle) {
            if (titlesContainer != null) {
                titlesContainer.setAlpha(1.0f - onTopAnimated);
            } else if (titleTextView[0] != null) {
                titleTextView[0].setAlpha(1.0f - onTopAnimated);
            }
        }

        final float factor = onTopAnimated;
        int lowerColor = adaptive_lowerColorKey == -1 ? 0 : Theme.getColor(adaptive_lowerColorKey, resourcesProvider);
        int topColor = adaptive_topColorKey == -1 ? 0 : Theme.getColor(adaptive_topColorKey, resourcesProvider);

        if (topColor == 0) {
            topColor = ColorUtils.setAlphaComponent(lowerColor, 0);
        }
        if (lowerColor == 0) {
            lowerColor = ColorUtils.setAlphaComponent(topColor, 0);
        }

        setBackgroundColor(ColorUtils.blendARGB(lowerColor, topColor, factor));
        setShadowAlpha((int) ((1.0f - onTopAnimated) * 0xFF));
        if (blurredBackground) {
            invalidate();
        }
    }

    private boolean isCentered() {
        // MeeroX: the iOS dialogs header centres its title. The fork already
        // supports a centred title, so the MeeroX switch just turns that on
        // instead of touching this layout code.
        if (meeroCenterTitle()) {
            return true;
        }
        return NaConfig.INSTANCE.getCenterActionBarTitle().Bool() && NaConfig.INSTANCE.getCenterActionBarTitleType().Int() != 3;
    }

    /** MeeroX: centre titles when the iOS dialogs style is on. */
    private boolean meeroCenterTitle() {
        try {
            return meeroAllowCenteredTitle
                    && tw.nekomimi.nekogram.NekoConfig.meeroDialogsStyle.Bool();
        } catch (Throwable e) {
            return false;
        }
    }

    /**
     * Set by DialogsActivity only. Other screens keep their own title
     * alignment so nothing else in the app shifts.
     */
    public boolean meeroAllowCenteredTitle;

    // --- Spring Animation ---
    public void onDrawCrossfadeBackground(Canvas canvas) {
        if (blurredBackground && actionBarColor != Color.TRANSPARENT) {
            rectTmp.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
            blurScrimPaint.setColor(actionBarColor);
            contentView.drawBlurRect(canvas, getY(), rectTmp, blurScrimPaint, true);
        } else {
            Drawable drawable = getBackground();
            if (drawable != null) {
                drawable.setBounds(0, 0, getWidth(), getHeight());
                drawable.draw(canvas);
            }
        }
    }

    public int getItemsColor() {
        return itemsColor;
    }
    // --- Spring Animation ---
}
