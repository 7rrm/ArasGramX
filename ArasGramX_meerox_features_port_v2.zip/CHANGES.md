# ArasGramX — MeeroX Features Port (v277 features → v235 base) — v2 (clean)

## الميزات المضافة
1. **عداد غير المقروء على زر الرجوع** (default ON) — تلقائي عند فتح محادثة
2. **شريط الدردشة العلوي** — قسم قابل للطي في إعدادات المحادثات مع معاينة حية
3. **معاينة الهيدر الحية** (MeeroHeaderPreviewView) — معاينة الكبسولة الزجاجية بأسمك وصورتك الحقيقية
4. **الكبسولة الزجاجية المركزية** (meeroCherryTitle) — توسيط عنوان الدردشة
5. **العرض المتكيّف** (meeroCherryAdaptive) — الكبسولة تتسع وتضيق حسب عرض الاسم
6. **مفتاح الرجوع للأصلي** (meeroHeaderStock) — يرجّع الهيدر لشكل تيليجرام الأصلي
7. **تأثير البريق** (meeroGlare) — لمعة زجاجية متحركة على كبسولة العنوان وفقاعات الرسائل
8. **شارة المجتمع المرتبط** (meeroCommunityBadge) — قرص أبيض على صور القنوات/المجموعات المرتبطة بمجتمع

## الميزات المُزالة (بناءً على طلبك)
- ❌ **توسيع العلامة** (MeeroVerifiedScaledDrawable) — تمت الإزالة بالكامل
- ❌ **خلفية المطور** (MeeroDevProfileBgDrawable) — تمت الإزالة بالكامل

## قائمة الملفات (15 ملف)

### ملفات جديدة (3)
- `Components/MeeroGlareLayer.java` — طبقة اللمعان الزجاجي
- `settings/MeeroHeaderPreviewView.java` — معاينة الهيدر الحية
- `nekogram/MeeroMsgMenu.java` — (تبعية compilation للميزات المطفية، لا يظهر في الإعدادات)

### ملفات معدّلة (12)
- `NekoConfig.java` — 5 إعدادات جديدة + تفعيل unreadBadgeOnBackButton افتراضياً
- `config/cell/ConfigCellCustom.java` — إضافة CUSTOM_ITEM_MeeroHeaderPreview
- `settings/NekoChatSettingsActivity.java` — قسم "شريط الدردشة العلوي ✦" قابل للطي
- `ChatActivity.java` — منطق isTitleCentered/meeroCherryTitleOn + معالجة centered header
- `ActionBar/ActionBar.java` — setChatAvatarContainer2 + adaptive width + capsule morph
- `Components/ChatAvatarContainer.java` — isCentered public + meeroGlareOn + معالجة اللمعان
- `ActionBar/Theme.java` — تثبيت ألوان verified الرسمية (إصلاح لون الشارة)
- `ProfileActivity.java` — تطبيق meeroCommunityBadge في البروفايل
- `Cells/DialogCell.java` — تطبيق meeroCommunityBadge في قائمة المحادثات
- `Cells/ProfileSearchCell.java` — تطبيق meeroCommunityBadge في نتائج البحث
- `Cells/UserCell.java` — تطبيق meeroCommunityBadge في قوائم المستخدمين
- `Cells/ChatMessageCell.java` — تأثير اللمعان على فقاعات الرسائل

## القيم الافتراضية
| الإعداد | الافتراضي |
|--------|----------|
| `unreadBadgeOnBackButton` | **true** ✅ (مفعّل) |
| `meeroCherryTitle` | **true** ✅ (مفعّل) |
| `meeroCherryAdaptive` | **true** ✅ (مفعّل) |
| `meeroGlare` | **true** ✅ (مفعّل) |
| `meeroHeaderStock` | false (مطفي) |
| `meeroCommunityBadge` | false (مطفي) |

## كيفية التركيب
1. فُك ضغط الملف
2. انسخ محتويات مجلد `TMessagesProj/src/main/` فوق الملفات الموجودة في مشروعك (نفس المسار)
3. اعمل build للتطبيق — القسم الجديد سيظهر في إعدادات المحادثات

## ملاحظات
- تم إزالة توسيع شارة verified — الشارة تبقى بالحجم الأصلي للتيليجرام
- تم إزالة خلفية المطور — لا يوجد كود يتحقق من username @i55544
- ميزات قائمة الرسائل (MeeroMsgMenu) مطفية افتراضياً ولا تظهر في الإعدادات
- القسم الجديد "شريط الدردشة العلوي ✦" يظهر أعلى شاشة إعدادات المحادثات
